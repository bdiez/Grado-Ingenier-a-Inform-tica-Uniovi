package uo227982.logica.acciones;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import uo227982.logica.modelo.Cliente;
import uo227982.logica.util.Parser;

public class AccionesCliente {
	private Parser p = new Parser();

	/**
	 * Metodo que muestra todos los usuarios registrados en la aplicacion
	 * 
	 * @return usuarios registrados en la aplicacion
	 */
	public List<Cliente> getUsuarios() {
		List<Cliente> usuarios = new ArrayList<>();
		List<String[]> datos = p.leerFichero("clientes.dat");
		for (String[] dato : datos) {
			Cliente usuario = new Cliente(dato[0], dato[1], dato[2], dato[3], dato[4], dato[5], dato[6], dato[7],
					Integer.valueOf(dato[8]));
			usuarios.add(usuario);
		}
		return usuarios;
	}

	/**
	 * A�ade un nuevo usuario al fichero "clientes.dat"
	 * 
	 * @param usuario
	 *            que queremos a�adir
	 * @return true/false dependiendo de si pudo a�adirlo o no
	 * @throws Exception
	 *             Si hay otro usuario en la aplicacion se muestra la excepcion
	 */
	public boolean addUsuario(Cliente u) throws Exception {
		if (!isDniRepetido(u.getNif()))
			return (p.grabarFichero(u.toString(), "clientes.dat",true) == 0) ? true : false;
		else
			throw new Exception("Ya hay otro usuario con ese nif");
	}

	/**
	 * Metodo que comprueba si un nif ya esta almacenado en la base de datos
	 * 
	 * @param nif
	 * @return
	 */
	private boolean isDniRepetido(String nif) {
		List<Cliente> clientes = getUsuarios();
		for (Cliente cliente : clientes) {
			if (cliente.getNif().equals(nif))
				return true;
		}
		return false;
	}

	/**
	 * Graba las usuarios en un documento
	 * 
	 * @param nombreFichero
	 * @param texto
	 * @throws IOException
	 */
	public void grabarUsuarios(String texto) throws IOException {
		String nombreFichero = "files/clientes.dat";
		File f = new File(nombreFichero);
		f.createNewFile();
		p.grabarFichero(texto, "clientes.dat", true);
	}

	public void borrarFichero() {
		String nombreFichero = "files/clientes.dat";
		File f = new File(nombreFichero);
		f.delete();
	}
}
