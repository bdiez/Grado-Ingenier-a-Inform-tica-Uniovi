package uo227982.logica.acciones;

import java.util.ArrayList;
import java.util.List;

import uo227982.logica.util.Parser;

public class AccionesMorosos {
	private Parser p = new Parser();
	public List<String> getMorosos(){
		List<String> morosos= new ArrayList<>();
		List<String[]> datos = p.leerFichero("morosos.dat");
		for (String[] dato : datos) {
			morosos.add(dato[0]);
		}
		return morosos;
	}
}
