package uo227982.logica.acciones;

import java.io.IOException;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.GregorianCalendar;
import java.util.List;

import uo227982.logica.modelo.Articulo;
import uo227982.logica.modelo.Cliente;
import uo227982.logica.modelo.tipos.AccionesPuntos;
import uo227982.logica.util.DateUtil;

public class Tienda {
	private static Tienda accionesTienda = new Tienda();

	private List<Articulo> carrito = new ArrayList<>();
	private Cliente usuario;
	private List<Articulo> almacen;
	private AccionesArticulo accionesArticulo;
	private double precioTotalCompra;
	private List<Cliente> usuarios = new ArrayList<>();
	private List<Articulo> regalos = new ArrayList<>();
	private List<String> morosos = new ArrayList<>();
	private int puntosTotalCompra;
	public AccionesPuntos accionesPuntos;

	private Tienda() {
		this.setAlmacen(llenarAlmacen());

		cargarRegalos();
		rellenarUsuarios();
		getMorosos();
	}

	private void getMorosos() {
		AccionesMorosos am = new AccionesMorosos();
		this.morosos = am.getMorosos();

	}

	public boolean comprobarClienteMoroso() {
		return (morosos.contains(usuario.getNif()));
	}

	public static Tienda getAccionesTienda() {
		return accionesTienda;
	}

	public static void setAccionesTienda(Tienda accionesTienda) {
		Tienda.accionesTienda = accionesTienda;
	}

	public List<Articulo> getCarrito() {
		return carrito;
	}

	public void setCarrito(ArrayList<Articulo> carrito) {
		this.carrito = carrito;
	}

	public Cliente getUsuario() {
		return usuario;
	}

	public void setUsuario(Cliente usuario) {
		this.usuario = usuario;
	}

	public List<Articulo> getAlmacen() {
		return almacen;
	}

	public void setAlmacen(List<Articulo> almacen) {
		this.almacen = almacen;
	}

	public String getDescripcionArticulo(int selectedRow) {
		return almacen.get(selectedRow).getDescripcion();
	}

	public String getCodigoArticulo(int selectedRow) {
		return almacen.get(selectedRow).getCodigo();

	}

	public int getStock(int selectedRow) {
		return almacen.get(selectedRow).getStock();
	}

	public int getUnidadesCarrito(int selectedRow) {
		return carrito.get(selectedRow).getStock();
	}

	public Articulo getArticuloByID(int selectedRow) {
		return almacen.get(selectedRow);
	}

	public AccionesArticulo getAccionesArticulo() {
		return accionesArticulo;
	}

	public void setAccionesArticulo(AccionesArticulo accionesArticulo) {
		this.accionesArticulo = accionesArticulo;
	}

	public void setCarrito(List<Articulo> carrito) {
		this.carrito = carrito;
	}

	public double getPrecioTotalCompra() {
		return precioTotalCompra;
	}

	public void setPrecioTotalCompra(double precioTotalCompra) {
		this.precioTotalCompra = precioTotalCompra;
	}

	/**
	 * Metodo que almacena en un array los usuarios de la aplicacion
	 */
	private void rellenarUsuarios() {
		AccionesCliente ac = new AccionesCliente();
		usuarios = ac.getUsuarios();
	}

	/**
	 * Metodo que actualiza los usuarios registrados
	 * 
	 * @throws IOException
	 */
	public void actualizarUsuarios() throws IOException {
		AccionesCliente ac = new AccionesCliente();

		ac.borrarFichero();
		for (Cliente cliente : usuarios) {
			if (cliente.getNif().equals(usuario.getNif()))
				cliente.setPuntos(puntosTotalCompra);
			ac.grabarUsuarios(cliente.toString());
		}

	}

	/**
	 * Metodo que llena el array con todos los articulos y les aplicaca un
	 * descuento aleatorio
	 * 
	 * @return
	 */
	private List<Articulo> llenarAlmacen() {
		accionesArticulo = new AccionesArticulo();
		return accionesArticulo.aplicarDescuentoCategoriaAleatoria(accionesArticulo.getArticulos());
	}

	/**
	 * Elimina un articulo del carrito
	 * 
	 * @param articulo
	 *            Articulo que se va a eliminar del carrito
	 */
	public void removeElementoCarrito(Articulo articulo) {
		for (Articulo articuloAlmacen : almacen) {
			if (articulo.equals(articuloAlmacen)) {
				articuloAlmacen.setStock(articulo.getStock() + articuloAlmacen.getStock());
				carrito.remove(articulo);
			}
		}
	}

	/**
	 * A�ade articulos al carrito
	 * 
	 * @param articulo
	 * @param cantidad
	 * @return
	 */
	public boolean addArticuloCarrito(Articulo articulo, int cantidad) {
		Articulo articuloCarrito = (Articulo) articulo.clone();
		if (cantidad > 0) {
			articuloCarrito.setStock(cantidad);
			articulo.setStock(articulo.getStock() - cantidad);
			return carrito.add(articuloCarrito);
		}
		return false;
	}

	/**
	 * Modifica los articulos
	 * 
	 * @param articulo
	 * @return
	 */
	public boolean modificarArticulo(Articulo articulo) {
		int pos = carrito.indexOf(articulo);
		if (pos > 0) {
			carrito.set(pos, articulo);
			return true;
		}
		return false;
	}

	/**
	 * Metodo que calcula el precio total de todos los articulos del carrito
	 * 
	 * @return
	 */
	public double calcularPrecioTotalCarrito() {
		this.precioTotalCompra = carrito.stream().mapToDouble(articulo -> articulo.getPrecio() * articulo.getStock())
				.sum();

		return precioTotalCompra;
	}

	/**
	 * Metodo que inicia sesion de un usario
	 * 
	 * @param usuario
	 */
	public void iniciarSesionUsuario(Cliente usuario) {
		this.usuario = usuario;
	}

	/**
	 * Metodo que devuelve el numero total de puntos que corresponden al usuario
	 * 
	 * @return
	 */
	public int getTotalPuntosUsuarioConCompra() {
		int puntosCompra = getTotalPuntosCompra();
		if (usuario != null)
			this.puntosTotalCompra = usuario.getPuntos() + puntosCompra;
		else
			this.puntosTotalCompra = puntosCompra;
		return this.puntosTotalCompra;
	}

	public int getTotalPuntosCompra() {
		int puntosCompra = carrito.stream().mapToInt(articulo -> articulo.getPuntosAsociados() * articulo.getStock())
				.sum();
		if (this.usuario != null && this.usuario.isVip())
			puntosCompra *= 2;
		return puntosCompra;
	}

	/**
	 * Metodo que muestra el estado de la compra al usuario
	 * 
	 * @return
	 * @throws ParseException
	 */
	public String mostrarEstadoCompra() throws ParseException {
		GregorianCalendar hoy = new GregorianCalendar();
		StringBuilder sb = new StringBuilder();
		sb.append("FACTURA - MEDIA-EII MARKET - " + DateUtil.format(hoy));
		sb.append("\n---------------------------------------------------------------------");
		sb.append("\nNOMBRE: " + usuario.getNombre().toUpperCase() + " " + usuario.getApellido().toUpperCase()
				+ "\tNIF: " + usuario.getNif());
		sb.append("\n---------------------------------------------------------------------");
		sb.append("\n** RELACION DE ARTICULOS COMPRADOS **");
		sb.append("\nDenominaci�n / C�digo / Unidades / Total art�culo ");
		sb.append("\n---------------------------------------------------------------------");
		sb.append(mostrarArticulosCarrito());
		sb.append("\n---------------------------------------------------------------------");
		if (getNumRegalosAdquiridos() > 0) {
			sb.append("\n** RELACION DE Regalos adquiridos **");
			sb.append("\nDenominaci�n / C�digo / Unidades / Total art�culo ");
			sb.append("\n---------------------------------------------------------------------");
			sb.append(mostrarRegalos());
		}
		sb.append("\nLos art�culos que tengan un * tienen un 10% de descuento");
		sb.append(
				"\nTotal articulos..................................................." + getPrecioTotalCompra() + "�");
		if (accionesPuntos == AccionesPuntos.DESCONTAR)
			sb.append("\nDescuento por puntos..................................................." + puntosTotalCompra
					+ "�");
		sb.append("\nTOTAL FACTURA..................................................." + getPrecioTotalCompra() + "�");
		return sb.toString();
	}

	private int getNumRegalosAdquiridos() {
		int numeroRegalos = 0;
		for (Articulo articulo : carrito) {
			if (articulo.isRegalo())
				numeroRegalos++;
		}
		return numeroRegalos;
	}

	private String mostrarRegalos() {
		StringBuilder sb = new StringBuilder();
		for (Articulo articulo : carrito) {
			if (articulo.isRegalo()) {
				sb.append("\n*");
				sb.append("Denominaci�n\t");
				sb.append(articulo.getDenominacion() + " / ");
				sb.append(articulo.getCodigo() + " / ");
			}
		}
		return sb.toString();
	}

	/**
	 * Metodo que crea la factura
	 * 
	 * @throws ParseException
	 */
	public void imprimirFactura() throws ParseException {
		accionesArticulo.grabarArticulos(usuario.getNif() + "(" + DateUtil.format(new GregorianCalendar()) + ")",
				mostrarEstadoCompra());
	}

	/**
	 * Metodo que muestra la informacion de los articulos del carrito
	 * 
	 * @return
	 */
	private String mostrarArticulosCarrito() {
		StringBuilder sb = new StringBuilder();
		for (Articulo articulo : carrito) {
			if (!articulo.isRegalo()) {
				sb.append("\n*");
				sb.append("Denominaci�n\t");
				sb.append(articulo.getDenominacion() + " / ");
				sb.append(articulo.getCodigo() + " / ");
				sb.append(articulo.getStock() + " / ");
				sb.append(articulo.getPrecio());
				if (articulo.isDescuento())
					sb.append("*");
			}
		}
		return sb.toString();
	}

	/**
	 * Metodo que a�ade los puntos de la compra al usuario
	 */
	public void acumularPuntos() {
		assert (accionesPuntos == AccionesPuntos.ACUMULAR);
		puntosTotalCompra = carrito.stream().mapToInt(articulo -> articulo.getPuntosAsociados() * articulo.getStock())
				.sum();
		if (usuario.isVip())
			puntosTotalCompra *= 2;
		puntosTotalCompra += usuario.getPuntos();

		usuario.setPuntos(puntosTotalCompra);

	}

	/**
	 * Metodo que carga los regalos
	 * 
	 * @return
	 */
	public void cargarRegalos() {
		AccionesRegalo ar = new AccionesRegalo();
		this.regalos = ar.getRegalos();
	}

	public List<Articulo> getRegalos() {
		return regalos;
	}

	public Integer getRegaloMenosPuntos() {
		Comparator<Articulo> comp = (a1, a2) -> Double.compare(a1.getPuntosAsociados(), a2.getPuntosAsociados());
		return regalos.stream().min(comp).get().getPuntosAsociados();

	}

	public List<Articulo> getRegalosByPuntosUsuario() {
		AccionesRegalo ar = new AccionesRegalo();
		return ar.getRegalosByPuntos(usuario.getPuntos());

	}

	public String getCodigoByDenominacion(String denominacion) {
		for (Articulo articulo : almacen) {
			if (articulo.getDenominacion().equals(denominacion))
				return articulo.getCodigo();
		}
		return null;
	}

	public String getDescripcionByDenominacion(String denominacion) {
		for (Articulo articulo : almacen) {
			if (articulo.getDenominacion().equals(denominacion))
				return articulo.getDescripcion();
		}
		return null;
	}

	public List<Cliente> getClientes() {
		return usuarios;
	}

	public void vaciarCarrito() {
		carrito.clear();
	}

	public void cerrarSesion() {
		vaciarCarrito();
		this.usuario = null;
	}

	public double descontarCompra() {
		double precioTotal = Tienda.getAccionesTienda().getPrecioTotalCompra();
		precioTotal -= Tienda.getAccionesTienda().getTotalPuntosUsuarioConCompra();
		this.usuario.setPuntos(0);
		return precioTotal;
	}

	public int getPuntosTotalCompra() {
		return puntosTotalCompra;
	}

	public void descontarPuntosRegalo() {
		for (Articulo articulo : carrito) {
			if (articulo.isRegalo())
				puntosTotalCompra += articulo.getPuntosAsociados();
		}

	}
}
