package uo227982.logica.acciones;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import uo227982.logica.modelo.Articulo;
import uo227982.logica.modelo.tipos.Categoria;
import uo227982.logica.util.Parser;

public class AccionesArticulo {
	private Parser p = new Parser();
	private static final String[] CATEGORIAS = { Categoria.CONSOLAS_Y_VIDEOJUEGOS.toString(),
			Categoria.FOTOGRAFIA_Y_VIDEO.toString(), Categoria.TELEFONIA_MOVIL.toString(),
			Categoria.ORDENADORES_Y_TABLETS.toString(), Categoria.VIDEOVIGILANCIA.toString() };

	/**
	 * Metodo que obtiene la lista de ficheros
	 * 
	 * @return
	 */
	public List<Articulo> getArticulos() {
		List<Articulo> articulos = new ArrayList<>();
		List<String[]> datos = p.leerFichero("articulos.dat");
		for (String[] dato : datos) {
			Articulo a = new Articulo(dato[0], dato[1], dato[2], dato[3], dato[4], Double.parseDouble(dato[5]),
					Integer.parseInt(dato[6]), Integer.parseInt(dato[7]));
			articulos.add(a);
		}

		return articulos;
	}

	/**
	 * Metodo que realiza el filtrado de los articulos por precio
	 * 
	 * @param articulos
	 * @param precioMaximo
	 * @param precioMinimo
	 * @return
	 */
	public List<Articulo> filtrarArticulosPorPrecio(List<Articulo> articulos, double precioMaximo,
			double precioMinimo) {
		Stream<Articulo> articulosFiltrado = articulos.stream()
				.filter(articulo -> articulo.getPrecio() <= precioMaximo && articulo.getPrecio() >= precioMinimo);
		return articulosFiltrado.collect(Collectors.toList());
	}

	/**
	 * Metodo que realizar el filtrado de los archivos por categoria
	 * 
	 * @param articulos
	 * @param categoria
	 * @return
	 */
	public List<Articulo> filtrarArticuloPorCategoria(List<Articulo> articulos, String categoria) {
		Stream<Articulo> articulosFiltrado = articulos.stream().filter(filtrarPorCategoria(articulos, categoria));
		return articulosFiltrado.collect(Collectors.toList());
	}

	private Predicate<Articulo> filtrarPorCategoria(List<Articulo> articulos, String categoria) {
		return articulo -> articulo.getCategoria().equalsIgnoreCase(categoria);
	}

	private Consumer<Articulo> descuento10 = articulo -> articulo
			.setPrecio(Math.round(articulo.getPrecio() - articulo.getPrecio() * 0.1));
	private Consumer<Articulo> ponerDescuento = articulo -> articulo.setDescuento(true);

	/**
	 * Metodo que aplica un descuento a una categoria aleatoria
	 * 
	 * @param articulos
	 * @return
	 */
	public List<Articulo> aplicarDescuentoCategoriaAleatoria(List<Articulo> articulos) {
		int numeroAleatorio = (int) ((Math.random() * 5));
		articulos.stream().filter(filtrarPorCategoria(articulos, CATEGORIAS[numeroAleatorio])).forEach(descuento10);
		articulos.stream().filter(filtrarPorCategoria(articulos, CATEGORIAS[numeroAleatorio])).forEach(ponerDescuento);
		return articulos;
	}

	public List<Articulo> aplicarDescuentoArticuloCategoria(List<Articulo> articulos) {
		List<String> categoriasConDescuento = new ArrayList<>();
		int numeroAleatorio = (int) ((Math.random() * articulos.size()));
		while (categoriasConDescuento.size() < 5) {
			if (!categoriasConDescuento.contains(articulos.get(numeroAleatorio).getCategoria())) {
				articulos.get(numeroAleatorio).setPrecio(Math.round(articulos.get(numeroAleatorio).getPrecio() * 0.1));
				articulos.get(numeroAleatorio).setDescuento(true);
				categoriasConDescuento.add(articulos.get(numeroAleatorio).getCategoria());
				numeroAleatorio = (int) ((Math.random() * articulos.size()));
			} else
				numeroAleatorio = (int) ((Math.random() * articulos.size()));
		}
		return articulos;

	}

	/**
	 * Graba las facturas en un documento
	 * 
	 * @param nombreFichero
	 * @param texto
	 */
	public void grabarArticulos(String nombreFichero, String texto) {
		p.grabarFichero(texto, nombreFichero,false);
	}

	/**
	 * Metodo que devuelve un articulo segun su denominacion
	 * 
	 * @param articulos
	 * @param denominacion
	 * @return
	 */
	public Articulo findByDenominacion(List<Articulo> articulos, String denominacion) {
		for (Articulo articulo : articulos) {
			if (articulo.getDenominacion().equals(denominacion))
				return articulo;
		}
		return null;
	}

}
