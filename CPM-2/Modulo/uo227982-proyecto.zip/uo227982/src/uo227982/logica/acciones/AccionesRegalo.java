package uo227982.logica.acciones;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import uo227982.logica.modelo.Articulo;
import uo227982.logica.util.Parser;

public class AccionesRegalo {
	private Parser parser;

	public AccionesRegalo() {
		this.parser = new Parser();
	}

	/**
	 * Metodo que devuelve todos los regalos del catalogo
	 * 
	 * @return
	 */
	public List<Articulo> getRegalos() {
		List<Articulo> regalos = new ArrayList<>();
		List<String[]> datos = parser.leerFichero("regalos.dat");
		for (String[] dato : datos) {
			Articulo articulo = new Articulo(dato[0], dato[1], "", dato[2], "", 0,Integer.valueOf(dato[3]),0);
			articulo.setRegalo(true);
			regalos.add(articulo);
		}
		return regalos;
	}

	/**
	 * Metodo que devuelve los elementos del catalogo disponibles con los puntos
	 * que tiene el usuario
	 * 
	 * @param puntos
	 *            que tiene el usuario
	 * @return elementos del catalogo disponibles con esos puntos
	 */
	public List<Articulo> getRegalosByPuntos(int puntos) {
		List<Articulo> regalos = getRegalos();
		Stream<Articulo> regalosPuntos = regalos.stream().filter(articulo -> articulo.getPuntosAsociados() <= puntos);
		return regalosPuntos.collect(Collectors.toList());
	}

}