package uo227982.logica.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;

public class Parser {
	/**
	 * M�todo que lee los diferentes ficheros que se le pasan por parametros y
	 * los trata
	 * 
	 * @param nombreFichero
	 * @return
	 */
	public List<String[]> leerFichero(String nombreFichero) {
		String linea = "";
		List<String[]> lineas = new ArrayList<>();
		try {
			BufferedReader fichero = new BufferedReader(new FileReader("files/" + nombreFichero));
			while (fichero.ready()) {
				linea = fichero.readLine();
				String[] trozos = linea.split(";");
				lineas.add(trozos);
			}
			fichero.close();
			return lineas;
		} catch (FileNotFoundException fnfe) {
			JOptionPane.showMessageDialog(null, "El archivo no se ha encontrado");
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
		}
		return null;
	}

	/**
	 * Metodo que crea un fichero
	 * 
	 * @param linea
	 * @param nombreFichero
	 * @return
	 */
	public int grabarFichero(String linea, String nombreFichero, boolean escritura) {
		nombreFichero = "files/" + nombreFichero;
		try {
			BufferedWriter fichero = new BufferedWriter(new FileWriter(nombreFichero, escritura));
			fichero.write(linea + "\n");
			fichero.close();
			return (0);
		} catch (FileNotFoundException fnfe) {
			System.out.println("El archivo no se ha podido guardar");
			return (-1);
		} catch (IOException ioe) {
			new RuntimeException("Error de entrada/salida.");
			return (-2);
		}
	}
}
