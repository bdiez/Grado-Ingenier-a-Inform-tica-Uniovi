package uo227982.logica.util;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.GregorianCalendar;

public class DateUtil {
	static SimpleDateFormat fmt = new SimpleDateFormat("dd-MMM-yyyy");

	/**
	 * Metodo que formatea las fechas
	 * 
	 * @param date
	 * @return
	 * @throws ParseException
	 */
	public static String format(GregorianCalendar date) throws ParseException {
		fmt.setCalendar(date);
		String dateFormatted = fmt.format(date.getTime());
		return dateFormatted;
	}

}