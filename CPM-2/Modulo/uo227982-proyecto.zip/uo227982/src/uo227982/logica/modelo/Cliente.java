package uo227982.logica.modelo;

public class Cliente {
	private String nombre;
	private String apellido;
	private String nif;
	private String nombreUsuario;
	private String contrase�a;
	private String numeroTelefo;
	private String numeroTarjeta;
	private int puntos;
	private boolean isVip;

	/**
	 * Constructor de la clase cliente
	 * 
	 * @param nombre
	 * @param apellido
	 * @param nif
	 * @param nombreUsuario
	 * @param contrase�a
	 * @param numeroTelefo
	 * @param numeroTarjeta
	 * @param puntos
	 */
	public Cliente(String vip, String nombre, String apellido, String nif, String nombreUsuario, String contrase�a,
			String numeroTelefo, String numeroTarjeta, int puntos) {
		this.nombre = nombre;
		this.apellido = apellido;
		this.nif = nif;
		this.nombreUsuario = nombreUsuario;
		this.contrase�a = contrase�a;
		this.numeroTelefo = numeroTelefo;
		this.numeroTarjeta = numeroTarjeta;
		this.puntos = puntos;
		this.setVip(esVip(vip));
	}

	private boolean esVip(String vip) {
		if (vip.equals("VIP"))
			return true;
		else
			return false;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}

	public String getApellido() {
		return apellido;
	}

	public void setApellido(String apellido) {
		this.apellido = apellido;
	}

	public String getNif() {
		return nif;
	}

	public void setNif(String nif) {
		this.nif = nif;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public String getContrase�a() {
		return contrase�a;
	}

	public void setContrase�a(String contrase�a) {
		this.contrase�a = contrase�a;
	}

	public String getNumeroTelefo() {
		return numeroTelefo;
	}

	public void setNumeroTelefo(String numeroTelefo) {
		this.numeroTelefo = numeroTelefo;
	}

	public String getNumeroTarjeta() {
		return numeroTarjeta;
	}

	public void setNumeroTarjeta(String numeroTarjeta) {
		this.numeroTarjeta = numeroTarjeta;
	}

	public int getPuntos() {
		return puntos;
	}

	public void setPuntos(int puntos) {
		this.puntos = puntos;
	}

	@Override
	public String toString() {
		return (isVip ? "VIP" : "NOVIP") + ";" + nombre + ";" + apellido + ";" + nif + ";" + nombreUsuario + ";"
				+ contrase�a + ";" + numeroTelefo + ";" + numeroTarjeta + ";" + puntos;
	}

	public boolean isVip() {
		return isVip;
	}

	public void setVip(boolean isVip) {
		this.isVip = isVip;
	}

}
