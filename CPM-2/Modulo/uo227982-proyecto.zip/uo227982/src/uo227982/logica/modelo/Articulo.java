package uo227982.logica.modelo;

import uo227982.logica.modelo.tipos.Categoria;

public class Articulo implements Cloneable {
	private String codigo;
	private Categoria categoria;
	private String subcategoria;
	private String denominacion;
	private String descripcion;
	private double precio;
	private int puntosAsociados;
	private int stock;
	private boolean descuento;
	private boolean regalo;

	/**
	 * Contructor de la clase articulo
	 * 
	 * @param codigo
	 * @param categoria
	 * @param subcategoria
	 * @param denominacion
	 * @param descripcion
	 * @param precio
	 * @param puntosAsociados
	 * @param stock
	 */
	public Articulo(String codigo, String categoria, String subcategoria, String denominacion, String descripcion,
			double precio, int puntosAsociados, int stock) {
		this.codigo = codigo;
		asignarCategoria(categoria);
		this.subcategoria = subcategoria;
		this.denominacion = denominacion;
		this.descripcion = descripcion;
		this.precio = precio;
		this.puntosAsociados = puntosAsociados;
		this.stock = stock;
	}

	public String getCodigo() {
		return codigo;
	}

	public void setCodigo(String codigo) {
		this.codigo = codigo;
	}

	public String getCategoria() {
		return categoria.toString();
	}

	public String getSubcategoria() {
		return subcategoria;
	}

	public void setSubcategoria(String subcategoria) {
		this.subcategoria = subcategoria;
	}

	public String getDenominacion() {
		return denominacion;
	}

	public void setDenominacion(String denominacion) {
		this.denominacion = denominacion;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public double getPrecio() {
		return precio;
	}

	public void setPrecio(double precio) {
		this.precio = precio;
	}

	public int getPuntosAsociados() {
		return puntosAsociados;
	}

	public void setPuntosAsociados(int puntosAsociados) {
		this.puntosAsociados = puntosAsociados;
	}

	public int getStock() {
		return stock;
	}

	public void setStock(int stock) {
		this.stock = stock;
	}

	public boolean isDescuento() {
		return descuento;
	}

	public void setDescuento(boolean descuento) {
		this.descuento = descuento;
	}

	public boolean isRegalo() {
		return regalo;
	}

	public void setRegalo(boolean regalo) {
		this.regalo = regalo;
	}

	/**
	 * Metodo que asigna las diferentes categorias al enum
	 * 
	 * @param aCategoria
	 */
	private void asignarCategoria(String aCategoria) {
		switch (aCategoria.toLowerCase()) {
		case "consolas y videojuegos":
			this.categoria = Categoria.CONSOLAS_Y_VIDEOJUEGOS;
			break;
		case "fotograf�a y v�deo":
			this.categoria = Categoria.FOTOGRAFIA_Y_VIDEO;
			break;
		case "telefon�a m�vil":
			this.categoria = Categoria.TELEFONIA_MOVIL;
			break;
		case "ordenadores y tablets":
			this.categoria = Categoria.ORDENADORES_Y_TABLETS;
			break;
		case "videovigilancia":
			this.categoria = Categoria.VIDEOVIGILANCIA;
			break;
		}
	}

	public Object clone() {
		Object obj = null;
		try {
			obj = super.clone();
		} catch (CloneNotSupportedException ex) {
			System.out.println(" no se puede duplicar");
		}
		return obj;

	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((categoria == null) ? 0 : categoria.hashCode());
		result = prime * result + ((codigo == null) ? 0 : codigo.hashCode());
		result = prime * result + ((denominacion == null) ? 0 : denominacion.hashCode());
		result = prime * result + ((descripcion == null) ? 0 : descripcion.hashCode());
		long temp;
		temp = Double.doubleToLongBits(precio);
		result = prime * result + (int) (temp ^ (temp >>> 32));
		result = prime * result + puntosAsociados;
		result = prime * result + stock;
		result = prime * result + ((subcategoria == null) ? 0 : subcategoria.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Articulo other = (Articulo) obj;
		if (categoria != other.categoria)
			return false;
		if (codigo == null) {
			if (other.codigo != null)
				return false;
		} else if (!codigo.equals(other.codigo))
			return false;
		if (denominacion == null) {
			if (other.denominacion != null)
				return false;
		} else if (!denominacion.equals(other.denominacion))
			return false;
		if (descripcion == null) {
			if (other.descripcion != null)
				return false;
		} else if (!descripcion.equals(other.descripcion))
			return false;
		if (Double.doubleToLongBits(precio) != Double.doubleToLongBits(other.precio))
			return false;
		if (subcategoria == null) {
			if (other.subcategoria != null)
				return false;
		} else if (!subcategoria.equals(other.subcategoria))
			return false;
		return true;
	}
	
	@Override
	public String toString() {
		return codigo + ";" + categoria.toString() + ";" + subcategoria + ";" + denominacion + ";" + descripcion + ";"
				+ precio + ";" + puntosAsociados + ";" + stock;
	}

}
