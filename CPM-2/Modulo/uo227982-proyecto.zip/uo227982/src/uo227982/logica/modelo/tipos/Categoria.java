package uo227982.logica.modelo.tipos;

public enum Categoria {
	CONSOLAS_Y_VIDEOJUEGOS("Consolas y Videojuegos"), FOTOGRAFIA_Y_VIDEO("Fotograf�a y V�deo"), TELEFONIA_MOVIL(
			"Telefon�a M�vil"), ORDENADORES_Y_TABLETS(
					"Ordenadores y Tablets"), VIDEOVIGILANCIA("Videovigilancia"), TODAS("Todas las categor�as");

	private String categoria;

	private Categoria(String categoria) {
		this.setCategoria(categoria);
	}

	@Override
	public String toString() {
		return categoria;
	}

	public String getCategoria() {
		return categoria;
	}

	private void setCategoria(String categoria) {
		this.categoria = categoria;

	}
}
