package uo227982.logica.modelo.tipos;

public enum AccionesPuntos {
	ACUMULAR, DESCONTAR, REGALO
}
