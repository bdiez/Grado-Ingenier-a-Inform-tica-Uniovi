package uo227982.igu;

import java.awt.BorderLayout;
import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Image;
import java.awt.Insets;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import javax.help.HelpBroker;
import javax.help.HelpSet;
import javax.swing.ButtonGroup;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JSeparator;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.table.DefaultTableCellRenderer;

import org.jvnet.substance.SubstanceLookAndFeel;
import org.jvnet.substance.skin.BusinessBlackSteelSkin;
import org.jvnet.substance.skin.SubstanceBusinessBlackSteelLookAndFeel;

import net.miginfocom.swing.MigLayout;
import uo227982.igu.util.ModeloNoEditable;
import uo227982.logica.acciones.Tienda;
import uo227982.logica.modelo.Articulo;
import uo227982.logica.modelo.Cliente;
import uo227982.logica.modelo.tipos.AccionesPuntos;
import uo227982.logica.modelo.tipos.Categoria;
import javax.swing.KeyStroke;
import java.awt.event.KeyEvent;
import java.awt.event.InputEvent;
import java.awt.FlowLayout;

public class VentanaPrincipal extends JFrame {

	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JPanel panelPantallaInicio;
	private JPanel panelPantallaInicioDerecha;
	private JPanel panelPantallaInicioCentro;
	private JPanel panelCabecera;
	private JButton btnAddElementoCarrito;
	private JScrollPane scrollPaneItems;
	private JTable tableItemsVenta;
	private ModeloNoEditable modeloTablaCatalogo;
	private JLabel lblogo;
	private JLabel lblEiiMarket;
	private JMenuBar menuBar;
	private JMenu mnArchivo;
	private JTextArea textAreaDescripcion;
	private JPanel panelBotonesVentanaInicio;
	private JLabel labelImagenItem;
	private JScrollPane scrollPaneDescripcion;
	private JPanel panelNortePantallaInicio;
	private JMenuItem mntmIniciarSesin;
	private JMenuItem mntmRegistrarse;
	private JMenuItem mntmSalir;
	private JSeparator separator;
	private JButton btnTramitarCompra;
	private JSpinner spinnerNumeroElementos;
	private JLabel lblCantidad;
	private JPanel panelCantidad;
	private JPanel panelPantallaInicioSur;
	private JLabel lblNoHayUsuario;
	private JMenu mnCarrito;
	private JMenuItem mntmVerCarrito;
	private JPanel panelIzquierdaPantallaInicio;
	private JComboBox<Categoria> comboBox;
	private JFormattedTextField textFieldPrecioMinimo;
	private JFormattedTextField textFieldPrecioMaximo;
	private JPanel panelIzquierdaCentroPantallaPrincipal;
	private JPanel panel_FiltradoPrecio_PrecioMaximo;
	private JPanel panel_FiltradoPrecio;
	private JLabel lblCategora;
	private JPanel panel_FiltradoCategoria;
	private JPanel panel_FiltradoPrecio_PrecioMinimo;
	private JButton btnFiltrar;
	private JPanel panelFormalizarCompra;
	private JPanel panel_FormalizarCompraCentral;
	private JLabel lblNombre;
	private JTextField textFieldNmbre;
	private JLabel lblApellido;
	private JTextField textFieldApellido;
	private JLabel lblNmeroDeCuenta;
	private JTextField textFieldNumeroDeCuenta;
	private JLabel lblNif;
	private JTextField textFieldNif;
	private JLabel lblTotalCompra;
	private JTextField textFieldTotalCompra;
	private JLabel lblPuntos;
	private JTextField textFieldPuntos;
	private JLabel lblPuntosCompra;
	private JLabel lblTotalPuntos;
	private JTextField textFieldCompra;
	private JTextField textFieldTotalPuntos;
	private JPanel panel_RadiobotonesPuntos;
	private JRadioButton rdbtnDescontarPuntosDel;
	private JRadioButton rdbtnAcumularPuntos;
	private JRadioButton rdbtnCanjearPorRegalo;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JScrollPane scrollPaneCarrito;
	private JTable tableCarrito;
	private ModeloNoEditable modeloTablaCarrito;
	private JPanel panel_BotonesFormalizarCompra;
	private JButton btnRetrocesoFormalizarCompra;
	private JButton btnFinalizarcompra;
	private JPanel panelFinCompra;
	private JTextArea textAreaResumenFinalCompra;
	private JPanel panel_BotonesFinCompra;
	private JButton btnAtrs;
	private JButton btnConfirmarCompra;
	private JMenu mnAyuda;
	private JMenuItem mntmAyudaDeEii;
	private JMenuItem mntmAcercaDeEii;
	private JLabel lblPrecioMnimo;
	private JLabel lblPrecioMximo;
	private JSeparator separator_ayuda;
	private JMenuItem mntmCerrarSesin;
	private JLabel lblVIP;
	private JSeparator separator_1;

	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					JFrame.setDefaultLookAndFeelDecorated(true);
					SubstanceLookAndFeel.setSkin(new BusinessBlackSteelSkin());
					UIManager.setLookAndFeel(new SubstanceBusinessBlackSteelLookAndFeel());
					VentanaPrincipal frame = new VentanaPrincipal();
					frame.setVisible(true);
					frame.setExtendedState(JFrame.MAXIMIZED_BOTH);
					frame.setMinimumSize(new Dimension(1024, 650));
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public VentanaPrincipal() {
		setIconImage(
				Toolkit.getDefaultToolkit().getImage(VentanaPrincipal.class.getResource("/uo227982/img/logo.PNG")));
		setTitle("Eii Market\r\n");
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setBounds(100, 100, 913, 606);
		setJMenuBar(getMenuBar_1());
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(new CardLayout(0, 0));
		contentPane.add(getPanelPantallaInicio(), "panelInicio");
		contentPane.add(getPanelFormalizarCompra(), "panelFormalizarCompra");
		contentPane.add(getPanelFinCompra(), "panelFinCompra");
		cargaAyuda();
	}

	// ----------------------------------------------//
	// Componentes ventana inicio
	private JPanel getPanelPantallaInicio() {
		if (panelPantallaInicio == null) {
			panelPantallaInicio = new JPanel();
			panelPantallaInicio.setLayout(new BorderLayout(0, 0));
			panelPantallaInicio.add(getPanelPantallaInicioDerecha(), BorderLayout.EAST);
			panelPantallaInicio.add(getPanelPantallaInicioCentro(), BorderLayout.CENTER);
			panelPantallaInicio.add(getPanelCabecera(), BorderLayout.NORTH);
			panelPantallaInicio.add(getPanelPantallaInicioSur(), BorderLayout.SOUTH);
			panelPantallaInicio.add(getPanelIzquierdaPantallaInicio(), BorderLayout.WEST);
		}
		return panelPantallaInicio;
	}

	private JPanel getPanelPantallaInicioDerecha() {
		if (panelPantallaInicioDerecha == null) {
			panelPantallaInicioDerecha = new JPanel();
			panelPantallaInicioDerecha.setLayout(new BorderLayout(0, 0));
			panelPantallaInicioDerecha.add(getPanelNortePantallaInicio(), BorderLayout.CENTER);
			panelPantallaInicioDerecha.add(getScrollPaneDescripcion(), BorderLayout.SOUTH);
			panelPantallaInicioDerecha.add(getLblNoHayUsuario(), BorderLayout.NORTH);
		}
		return panelPantallaInicioDerecha;
	}

	private JPanel getPanelPantallaInicioCentro() {
		if (panelPantallaInicioCentro == null) {
			panelPantallaInicioCentro = new JPanel();
			panelPantallaInicioCentro.setLayout(new BorderLayout(0, 0));
			panelPantallaInicioCentro.add(getScrollPaneItems());
		}
		return panelPantallaInicioCentro;
	}

	private JPanel getPanelCabecera() {
		if (panelCabecera == null) {
			panelCabecera = new JPanel();
			GridBagLayout gbl_panelCabecera = new GridBagLayout();
			gbl_panelCabecera.columnWidths = new int[] { 185, 511, 0, 0 };
			gbl_panelCabecera.rowHeights = new int[] { 110, 0 };
			gbl_panelCabecera.columnWeights = new double[] { 0.0, 0.0, 1.0, Double.MIN_VALUE };
			gbl_panelCabecera.rowWeights = new double[] { 1.0, Double.MIN_VALUE };
			panelCabecera.setLayout(gbl_panelCabecera);
			GridBagConstraints gbc_lblogo = new GridBagConstraints();
			gbc_lblogo.anchor = GridBagConstraints.NORTHWEST;
			gbc_lblogo.insets = new Insets(0, 0, 0, 5);
			gbc_lblogo.gridx = 0;
			gbc_lblogo.gridy = 0;
			panelCabecera.add(getLblogo(), gbc_lblogo);
			GridBagConstraints gbc_lblEiiMarket = new GridBagConstraints();
			gbc_lblEiiMarket.insets = new Insets(0, 0, 0, 5);
			gbc_lblEiiMarket.gridx = 1;
			gbc_lblEiiMarket.gridy = 0;
			panelCabecera.add(getLblEiiMarket(), gbc_lblEiiMarket);
		}
		return panelCabecera;
	}

	private JButton getBtnAddElementoCarrito() {
		if (btnAddElementoCarrito == null) {
			btnAddElementoCarrito = new JButton("A\u00F1adir al carrito");
			btnAddElementoCarrito.setEnabled(false);
			btnAddElementoCarrito.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					int fila = tableItemsVenta.getSelectedRow();
					Articulo articulo = Tienda.getAccionesTienda().getArticuloByID(fila);
					Tienda.getAccionesTienda().addArticuloCarrito(articulo, (int) spinnerNumeroElementos.getValue());
					tableItemsVenta.setValueAt(Tienda.getAccionesTienda().getStock(fila), fila, 5);
					asignarMaximoSpinner();
					activarBotonSiguiente();
					mntmVerCarrito.setEnabled(true);

				}
			});
		}
		return btnAddElementoCarrito;
	}

	private void activarBotonSiguiente() {
		btnTramitarCompra.setEnabled(!Tienda.getAccionesTienda().getCarrito().isEmpty());
	}

	private JScrollPane getScrollPaneItems() {
		if (scrollPaneItems == null) {
			scrollPaneItems = new JScrollPane();
			scrollPaneItems.setViewportView(getTableItemsVenta());
		}
		return scrollPaneItems;
	}

	private JTable getTableItemsVenta() {
		if (tableItemsVenta == null) {
			String[] nombreColumnas = { "Denominaci�n", "Categor�a", "Subcategor�a", "Precio", "Puntos", "Stock",
					"Descuento" };
			List<Articulo> articulos = Tienda.getAccionesTienda().getAlmacen();
			modeloTablaCatalogo = new ModeloNoEditable(nombreColumnas, 0);
			tableItemsVenta = new JTable(modeloTablaCatalogo);
			tableItemsVenta.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			a�adirFilas(articulos, modeloTablaCatalogo);
			tableItemsVenta.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					mostrarDatosArticulo();
					mostrarImagenArticulo();
					if (tableItemsVenta.getSelectedRow() != -1) {

						btnAddElementoCarrito.setEnabled(true);
						spinnerNumeroElementos.setEnabled(true);
						asignarMaximoSpinner();
					}
				}

			});
			for (int i = 0; i < nombreColumnas.length; i++) {
				centrarColumna(nombreColumnas[i], tableItemsVenta);
			}
			tableItemsVenta.setModel(modeloTablaCatalogo);
			tableItemsVenta.getTableHeader().setReorderingAllowed(false);

		}
		return tableItemsVenta;
	}

	private void asignarMaximoSpinner() {
		int max = Tienda.getAccionesTienda().getStock(tableItemsVenta.getSelectedRow());
		if (max > 0) {
			spinnerNumeroElementos.setModel(new SpinnerNumberModel(1, 1, max, 1));
			spinnerNumeroElementos.setValue(0);
		} else {
			spinnerNumeroElementos.setEnabled(false);
			btnAddElementoCarrito.setEnabled(false);
		}

	}

	private void a�adirFilas(List<Articulo> articulos, ModeloNoEditable modelo) {
		Object[] nuevaFila = new Object[7];
		for (Articulo articulo : articulos) {
			nuevaFila[0] = articulo.getDenominacion();
			nuevaFila[1] = articulo.getCategoria();
			nuevaFila[2] = articulo.getSubcategoria();
			nuevaFila[3] = articulo.getPrecio();
			nuevaFila[4] = articulo.getPuntosAsociados();
			nuevaFila[5] = articulo.getStock();
			nuevaFila[6] = establecerValor(articulo.isDescuento());
			modelo.addRow(nuevaFila);
		}
	}

	private String establecerValor(boolean tieneDescuento) {
		if (tieneDescuento)
			return "Si";
		return "No";
	}

	private void addFilasTablaCarrito(List<Articulo> articulos, ModeloNoEditable modelo) {
		Object[] nuevaFila = new Object[6];
		for (Articulo articulo : articulos) {
			nuevaFila[0] = articulo.getDenominacion();
			nuevaFila[1] = articulo.getPrecio();
			nuevaFila[2] = articulo.getStock();
			nuevaFila[3] = articulo.getPuntosAsociados();

			modelo.addRow(nuevaFila);
		}
	}

	private void mostrarDatosArticulo() {
		String denominacionarticulo = (String) modeloTablaCatalogo.getValueAt(tableItemsVenta.getSelectedRow(), 0);
		textAreaDescripcion.setText(Tienda.getAccionesTienda().getDescripcionByDenominacion(denominacionarticulo));
	}

	private void mostrarImagenArticulo() {
		String denominacionarticulo = (String) modeloTablaCatalogo.getValueAt(tableItemsVenta.getSelectedRow(), 0);
		String img = "/uo227982/img/" + Tienda.getAccionesTienda().getCodigoByDenominacion(denominacionarticulo)
				+ ".jpg";
		adaptarImagenLabel(labelImagenItem, img);
	}

	private JLabel getLblogo() {
		if (lblogo == null) {
			lblogo = new JLabel("");
			lblogo.setIcon(new ImageIcon(VentanaPrincipal.class.getResource("/uo227982/img/logo.PNG")));
			lblogo.setHorizontalAlignment(SwingConstants.TRAILING);
		}
		return lblogo;
	}

	private JLabel getLblEiiMarket() {
		if (lblEiiMarket == null) {
			lblEiiMarket = new JLabel("EII Market");
			lblEiiMarket.setFont(new Font("Segoe Script", Font.PLAIN, 30));
		}
		return lblEiiMarket;
	}

	private JMenuBar getMenuBar_1() {
		if (menuBar == null) {
			menuBar = new JMenuBar();
			menuBar.add(getMnArchivo());
			menuBar.add(getMnCarrito());
			menuBar.add(getMnAyuda());
		}
		return menuBar;
	}

	private JMenu getMnArchivo() {
		if (mnArchivo == null) {
			mnArchivo = new JMenu("Archivo");
			mnArchivo.setMnemonic('A');
			mnArchivo.add(getMntmIniciarSesin());
			mnArchivo.add(getMntmRegistrarse());
			mnArchivo.add(getSeparator_1());
			mnArchivo.add(getMntmCerrarSesin());
			mnArchivo.add(getSeparator());
			mnArchivo.add(getMntmSalir());
		}
		return mnArchivo;
	}

	private JTextArea getTextAreaDescripcion() {
		if (textAreaDescripcion == null) {
			textAreaDescripcion = new JTextArea(10, 20);
			textAreaDescripcion.setEditable(false);
			textAreaDescripcion.setWrapStyleWord(true);
			textAreaDescripcion.setLineWrap(true);

		}
		return textAreaDescripcion;
	}

	private JPanel getPanelBotonesVentanaInicio() {
		if (panelBotonesVentanaInicio == null) {
			panelBotonesVentanaInicio = new JPanel();
			panelBotonesVentanaInicio.add(getPanelCantidad());
			panelBotonesVentanaInicio.add(getBtnAddElementoCarrito());
			panelBotonesVentanaInicio.add(getBtnTramitarCompra());
		}
		return panelBotonesVentanaInicio;
	}

	private JLabel getLabelImagenItem() {
		if (labelImagenItem == null) {
			labelImagenItem = new JLabel();
			labelImagenItem.setBounds(new Rectangle(0, 0, 250, 250));
			adaptarImagenLabel(labelImagenItem, "/uo227982/img/lupa.png");

		}
		return labelImagenItem;
	}

	private JScrollPane getScrollPaneDescripcion() {
		if (scrollPaneDescripcion == null) {
			scrollPaneDescripcion = new JScrollPane();
			scrollPaneDescripcion.setViewportView(getTextAreaDescripcion());
		}
		return scrollPaneDescripcion;
	}

	private JPanel getPanelNortePantallaInicio() {
		if (panelNortePantallaInicio == null) {
			panelNortePantallaInicio = new JPanel();
			panelNortePantallaInicio.add(getLabelImagenItem());
		}
		return panelNortePantallaInicio;
	}

	private void adaptarImagenLabel(JLabel label, String rutaImagen) {
		Image imgOriginal = new ImageIcon(getClass().getResource(rutaImagen)).getImage();
		Image imgEscalada = imgOriginal.getScaledInstance((int) (label.getWidth()), (int) (label.getHeight()),
				Image.SCALE_FAST);
		label.setIcon(new ImageIcon(imgEscalada));
	}

	private JMenuItem getMntmIniciarSesin() {
		if (mntmIniciarSesin == null) {
			mntmIniciarSesin = new JMenuItem("Iniciar sesi\u00F3n");
			mntmIniciarSesin.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_I, InputEvent.CTRL_MASK));
			mntmIniciarSesin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					VentanaIniciarSesion vi = new VentanaIniciarSesion();
					vi.setLocationRelativeTo(null);
					vi.addWindowListener(new WindowAdapter() {
						@Override
						public void windowClosed(WindowEvent e) {
							actualizarInformacionUsuario();
							if (Tienda.getAccionesTienda().getUsuario() != null)
								mntmCerrarSesin.setEnabled(true);
							if (Tienda.getAccionesTienda().comprobarClienteMoroso()) {
								tableItemsVenta.setEnabled(false);
								JOptionPane.showMessageDialog(null,
										"El usuario se encuentra en la lista de morosos y no puede realizar ninguna compra");
								btnAddElementoCarrito.setEnabled(false);
								btnTramitarCompra.setEnabled(false);
							}
						}

					});
					vi.setVisible(true);

				}
			});
		}
		return mntmIniciarSesin;
	}

	private void actualizarInformacionUsuario() {
		if (Tienda.getAccionesTienda().getUsuario() != null) {
			lblNoHayUsuario.setText("Bienvenido, " + Tienda.getAccionesTienda().getUsuario().getNombre() + " tiene "
					+ Tienda.getAccionesTienda().getUsuario().getPuntos() + " puntos y es usuario "
					+ (Tienda.getAccionesTienda().getUsuario().isVip() ? "VIP" : "NOVIP"));
			aplicarDescuentoCategoriaAleatoria();
		} else
			lblNoHayUsuario.setText("No hay usuario en sesi�n");

	}

	private void aplicarDescuentoCategoriaAleatoria() {
		List<Articulo> articulos = Tienda.getAccionesTienda().getAccionesArticulo()
				.aplicarDescuentoArticuloCategoria(Tienda.getAccionesTienda().getAlmacen());
		Tienda.getAccionesTienda().setAlmacen(articulos);
		clearTabla();
		a�adirFilas(articulos, modeloTablaCatalogo);

	}

	private JMenuItem getMntmRegistrarse() {
		if (mntmRegistrarse == null) {
			mntmRegistrarse = new JMenuItem("Registrarse ");
			mntmRegistrarse.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N, InputEvent.CTRL_MASK));
			mntmRegistrarse.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					VentanaRegistroUsuario vru = new VentanaRegistroUsuario();
					vru.setLocationRelativeTo(null);
					vru.setVisible(true);
				}
			});
		}
		return mntmRegistrarse;
	}

	private JMenuItem getMntmSalir() {
		if (mntmSalir == null) {
			mntmSalir = new JMenuItem("Salir");
			mntmSalir.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					dispose();
				}
			});
			mntmSalir.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q, InputEvent.CTRL_MASK));
		}
		return mntmSalir;
	}

	private JSeparator getSeparator() {
		if (separator == null) {
			separator = new JSeparator();
		}
		return separator;
	}

	private JButton getBtnTramitarCompra() {
		if (btnTramitarCompra == null) {
			btnTramitarCompra = new JButton("Tramitar compra");
			btnTramitarCompra.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					clearTablaCarrito();
					((CardLayout) contentPane.getLayout()).show(contentPane, "panelFormalizarCompra");
					rellenarDatosCompra();
					addFilasTablaCarrito(Tienda.getAccionesTienda().getCarrito(), modeloTablaCarrito);
					mntmVerCarrito.setEnabled(false);
					mntmCerrarSesin.setEnabled(false);
					mntmIniciarSesin.setEnabled(false);
					mntmRegistrarse.setEnabled(false);
					rdbtnAcumularPuntos.setEnabled(true);
					rdbtnCanjearPorRegalo.setEnabled(true);
					rdbtnDescontarPuntosDel.setEnabled(true);
					rdbtnAcumularPuntos.setSelected(false);
					rdbtnCanjearPorRegalo.setSelected(false);
					rdbtnDescontarPuntosDel.setSelected(false);
					if (Tienda.getAccionesTienda().getUsuario() != null
							&& Tienda.getAccionesTienda().getUsuario().isVip())
						lblVIP.setText("El usuario es VIP y los puntos obtenidos se multiplican por dos");
					else
						lblVIP.setText("");
					if (Tienda.getAccionesTienda().getUsuario() == null)
						getPanel_RadiobotonesPuntos().setVisible(false);
					else {
						textFieldApellido.setEditable(false);
						textFieldNif.setEditable(false);
						textFieldNumeroDeCuenta.setEditable(false);
						textFieldNmbre.setEditable(false);
						getPanel_RadiobotonesPuntos().setVisible(true);
						getPanel_RadiobotonesPuntos().setEnabled(true);
					}
				}

			});
			btnTramitarCompra.setEnabled(false);
		}
		return btnTramitarCompra;
	}

	private void clearTablaCarrito() {
		for (int i = 0; i < tableCarrito.getRowCount(); i++) {
			modeloTablaCarrito.removeRow(i);
			i -= 1;
		}
	}

	// -------------------------------------------------------------//
	// Ventana confirmacion compra
	// -------------------------------------------------------------//

	private void rellenarDatosCompra() {
		if (Tienda.getAccionesTienda().getUsuario() != null) {
			textFieldApellido.setText(Tienda.getAccionesTienda().getUsuario().getApellido());
			textFieldNmbre.setText(Tienda.getAccionesTienda().getUsuario().getNombre());
			textFieldNif.setText(Tienda.getAccionesTienda().getUsuario().getNif());
			textFieldPuntos.setText(String.valueOf(Tienda.getAccionesTienda().getUsuario().getPuntos()));
			textFieldNumeroDeCuenta.setText(Tienda.getAccionesTienda().getUsuario().getNumeroTarjeta());
		}
		textFieldCompra.setText(String.valueOf(Tienda.getAccionesTienda().getTotalPuntosCompra()));
		textFieldTotalCompra.setText(String.valueOf(Tienda.getAccionesTienda().calcularPrecioTotalCarrito()));
		textFieldTotalPuntos.setText(String.valueOf(Tienda.getAccionesTienda().getTotalPuntosUsuarioConCompra()));
	}

	private JSpinner getSpinnerNumeroElementos() {
		if (spinnerNumeroElementos == null) {
			spinnerNumeroElementos = new JSpinner();
			spinnerNumeroElementos.setPreferredSize(new Dimension(50, 20));
			spinnerNumeroElementos.setEnabled(false);
			spinnerNumeroElementos.setEditor(new JSpinner.DefaultEditor(spinnerNumeroElementos));
			spinnerNumeroElementos.setModel(new SpinnerNumberModel(0, 0, 2, 1));
		}
		return spinnerNumeroElementos;
	}

	private JLabel getLblCantidad() {
		if (lblCantidad == null) {
			lblCantidad = new JLabel("Cantidad:");
			lblCantidad.setLabelFor(getSpinnerNumeroElementos());
		}
		return lblCantidad;
	}

	private JPanel getPanelCantidad() {
		if (panelCantidad == null) {
			panelCantidad = new JPanel();
			panelCantidad.setLayout(new BorderLayout(0, 0));
			panelCantidad.add(getLblCantidad(), BorderLayout.WEST);
			panelCantidad.add(getSpinnerNumeroElementos(), BorderLayout.EAST);
		}
		return panelCantidad;
	}

	private JPanel getPanelPantallaInicioSur() {
		if (panelPantallaInicioSur == null) {
			panelPantallaInicioSur = new JPanel();
			panelPantallaInicioSur.setLayout(new BorderLayout(0, 0));
			panelPantallaInicioSur.add(getPanelBotonesVentanaInicio());
		}
		return panelPantallaInicioSur;
	}

	private JLabel getLblNoHayUsuario() {
		if (lblNoHayUsuario == null) {
			lblNoHayUsuario = new JLabel("No hay usuario en sesi\u00F3n");
			lblNoHayUsuario.setHorizontalAlignment(SwingConstants.CENTER);
		}
		return lblNoHayUsuario;
	}

	private JMenu getMnCarrito() {
		if (mnCarrito == null) {
			mnCarrito = new JMenu("Carrito");
			mnCarrito.setMnemonic('C');
			mnCarrito.add(getMntmVerCarrito());
		}
		return mnCarrito;
	}

	private JMenuItem getMntmVerCarrito() {
		if (mntmVerCarrito == null) {
			mntmVerCarrito = new JMenuItem("Ver carrito");
			mntmVerCarrito.setEnabled(false);
			mntmVerCarrito.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_A, InputEvent.CTRL_MASK));
			mntmVerCarrito.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					VentanaCarrito vc = new VentanaCarrito();
					vc.setVisible(true);
					vc.addWindowListener(new WindowAdapter() {
						@Override
						public void windowClosed(WindowEvent e) {
							clearTabla();
							a�adirFilas(Tienda.getAccionesTienda().getAlmacen(), modeloTablaCatalogo);
							if (Tienda.getAccionesTienda().getCarrito().isEmpty())
								btnTramitarCompra.setEnabled(false);
						}

					});

				}
			});
		}
		return mntmVerCarrito;
	}

	private JPanel getPanelIzquierdaPantallaInicio() {
		if (panelIzquierdaPantallaInicio == null) {
			panelIzquierdaPantallaInicio = new JPanel();
			panelIzquierdaPantallaInicio
					.setBorder(new TitledBorder(null, "Filtrados", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelIzquierdaPantallaInicio.setLayout(new BorderLayout(0, 0));
			panelIzquierdaPantallaInicio.add(getPanel_FiltradoCategoria(), BorderLayout.NORTH);
			panelIzquierdaPantallaInicio.add(getPanelIzquierdaCentroPantallaPrincipal(), BorderLayout.CENTER);
		}
		return panelIzquierdaPantallaInicio;
	}

	private JComboBox<Categoria> getComboBox() {
		if (comboBox == null) {
			comboBox = new JComboBox<Categoria>();
			comboBox.addItemListener(new ItemListener() {
				public void itemStateChanged(ItemEvent arg0) {
					List<Articulo> articulosFiltrado = new ArrayList<>();
					if (comboBox.getSelectedItem().toString().equals("Todas las categor�as")) {
						articulosFiltrado = Tienda.getAccionesTienda().getAlmacen();
					} else {
						articulosFiltrado = Tienda.getAccionesTienda().getAccionesArticulo()
								.filtrarArticuloPorCategoria(Tienda.getAccionesTienda().getAlmacen(),
										comboBox.getSelectedItem().toString());
					}
					clearTabla();
					a�adirFilas(articulosFiltrado, modeloTablaCatalogo);
				}
			});
			comboBox.setModel(new DefaultComboBoxModel<Categoria>(Categoria.values()));
			comboBox.setSelectedIndex(5);
		}
		return comboBox;
	}

	private JFormattedTextField getTextFieldPrecioMinimo() {
		if (textFieldPrecioMinimo == null) {
			textFieldPrecioMinimo = new JFormattedTextField(DecimalFormat.getNumberInstance(Locale.getDefault()));
			textFieldPrecioMinimo.setColumns(10);
		}
		return textFieldPrecioMinimo;
	}

	private JFormattedTextField getTextFieldPrecioMaximo() {
		if (textFieldPrecioMaximo == null) {
			DecimalFormat format = new DecimalFormat("####.####");
			textFieldPrecioMaximo = new JFormattedTextField(format);
			textFieldPrecioMaximo.setColumns(10);
		}
		return textFieldPrecioMaximo;
	}

	private JPanel getPanelIzquierdaCentroPantallaPrincipal() {
		if (panelIzquierdaCentroPantallaPrincipal == null) {
			panelIzquierdaCentroPantallaPrincipal = new JPanel();
			panelIzquierdaCentroPantallaPrincipal.setLayout(new GridLayout(3, 1, 0, 0));
			panelIzquierdaCentroPantallaPrincipal.add(getPanel_FiltradoPrecio());
		}
		return panelIzquierdaCentroPantallaPrincipal;
	}

	private JPanel getPanel_FiltradoPrecio_PrecioMaximo() {
		if (panel_FiltradoPrecio_PrecioMaximo == null) {
			panel_FiltradoPrecio_PrecioMaximo = new JPanel();
			panel_FiltradoPrecio_PrecioMaximo.setBorder(
					new TitledBorder(null, "Precio m\u00E1ximo", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panel_FiltradoPrecio_PrecioMaximo.setLayout(new BorderLayout(0, 0));
			panel_FiltradoPrecio_PrecioMaximo.add(getLblPrecioMximo(), BorderLayout.WEST);
			panel_FiltradoPrecio_PrecioMaximo.add(getTextFieldPrecioMaximo());
		}
		return panel_FiltradoPrecio_PrecioMaximo;
	}

	private JPanel getPanel_FiltradoPrecio() {
		if (panel_FiltradoPrecio == null) {
			panel_FiltradoPrecio = new JPanel();
			panel_FiltradoPrecio.setLayout(new GridLayout(3, 1, 0, 0));
			panel_FiltradoPrecio.add(getPanel_FiltradoPrecio_PrecioMinimo());
			panel_FiltradoPrecio.add(getPanel_FiltradoPrecio_PrecioMaximo());
			panel_FiltradoPrecio.add(getBtnFiltrar());
		}
		return panel_FiltradoPrecio;
	}

	private JLabel getLblCategora() {
		if (lblCategora == null) {
			lblCategora = new JLabel("Categor\u00EDa:");
		}
		return lblCategora;
	}

	private JPanel getPanel_FiltradoCategoria() {
		if (panel_FiltradoCategoria == null) {
			panel_FiltradoCategoria = new JPanel();
			panel_FiltradoCategoria.add(getLblCategora());
			panel_FiltradoCategoria.add(getComboBox());
		}
		return panel_FiltradoCategoria;
	}

	private JPanel getPanel_FiltradoPrecio_PrecioMinimo() {
		if (panel_FiltradoPrecio_PrecioMinimo == null) {
			panel_FiltradoPrecio_PrecioMinimo = new JPanel();
			panel_FiltradoPrecio_PrecioMinimo.setBorder(
					new TitledBorder(null, "Precio m\u00EDnimo", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panel_FiltradoPrecio_PrecioMinimo.setLayout(new BorderLayout(0, 0));
			panel_FiltradoPrecio_PrecioMinimo.add(getLblPrecioMnimo(), BorderLayout.WEST);
			panel_FiltradoPrecio_PrecioMinimo.add(getTextFieldPrecioMinimo());
		}
		return panel_FiltradoPrecio_PrecioMinimo;
	}

	private JButton getBtnFiltrar() {
		if (btnFiltrar == null) {
			btnFiltrar = new JButton("Filtrar");
			btnFiltrar.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					DecimalFormat format = new DecimalFormat("####.####");
					double precioMinimo;
					try {
						if (!(textFieldPrecioMinimo.getText().equals("")
								&& textFieldPrecioMaximo.getText().equals(""))) {
							precioMinimo = format.parse(textFieldPrecioMinimo.getText()).doubleValue();
							double precioMaximo = format.parse(textFieldPrecioMaximo.getText()).doubleValue();
							List<Articulo> filtrado = Tienda.getAccionesTienda().getAccionesArticulo()
									.filtrarArticulosPorPrecio(Tienda.getAccionesTienda().getAlmacen(), precioMaximo,
											precioMinimo);
							if (!comboBox.getSelectedItem().toString().equals("Todas las categor�as")) {
								List<Articulo> filtradoConCategoria = Tienda.getAccionesTienda().getAccionesArticulo()
										.filtrarArticuloPorCategoria(filtrado, comboBox.getSelectedItem().toString());
								clearTabla();
								a�adirFilas(filtradoConCategoria, modeloTablaCatalogo);
							} else {
								clearTabla();
								a�adirFilas(filtrado, modeloTablaCatalogo);
							}
						} else
							JOptionPane.showMessageDialog(null, "Debe establecer un precio m�ximo y m�mino");
					} catch (ParseException e) {
						e.printStackTrace();
					}

				}
			});
		}
		return btnFiltrar;
	}

	private void clearTabla() {
		for (int i = 0; i < tableItemsVenta.getRowCount(); i++) {
			modeloTablaCatalogo.removeRow(i);
			i -= 1;
		}
	}

	private JPanel getPanelFormalizarCompra() {
		if (panelFormalizarCompra == null) {
			panelFormalizarCompra = new JPanel();
			panelFormalizarCompra.setLayout(new BorderLayout(0, 0));
			panelFormalizarCompra.add(getPanel_FormalizarCompraCentral(), BorderLayout.CENTER);
		}
		return panelFormalizarCompra;
	}

	private JPanel getPanel_FormalizarCompraCentral() {
		if (panel_FormalizarCompraCentral == null) {
			panel_FormalizarCompraCentral = new JPanel();
			panel_FormalizarCompraCentral.setLayout(
					new MigLayout("", "[288.00px,grow][86px,grow][41px][103.00px][79.00px][367.00,grow][-92.00px]",
							"[34.00px][][][][][][][135.00,grow][grow][][][][][][][][][grow]"));
			panel_FormalizarCompraCentral.add(getLblNombre(), "cell 0 0,alignx left,aligny center");
			panel_FormalizarCompraCentral.add(getTextFieldNmbre(), "cell 1 0,growx,aligny center");
			panel_FormalizarCompraCentral.add(getLblVIP(), "cell 5 0");
			panel_FormalizarCompraCentral.add(getLblApellido(), "cell 0 1,alignx left,aligny center");
			panel_FormalizarCompraCentral.add(getTextFieldApellido(), "cell 1 1,growx,aligny center");
			panel_FormalizarCompraCentral.add(getLblNmeroDeCuenta(), "cell 0 2,alignx left,aligny center");
			panel_FormalizarCompraCentral.add(getTextFieldNumeroDeCuenta(), "cell 1 2,growx,aligny center");
			panel_FormalizarCompraCentral.add(getLblNif(), "cell 0 3,alignx left");
			panel_FormalizarCompraCentral.add(getTextFieldNif(), "cell 1 3,growx,aligny center");
			panel_FormalizarCompraCentral.add(getLblPuntos(), "cell 0 4,alignx left");
			panel_FormalizarCompraCentral.add(getTextFieldPuntos(), "cell 1 4,growx");
			panel_FormalizarCompraCentral.add(getLblPuntosCompra(), "cell 0 5,alignx left");
			panel_FormalizarCompraCentral.add(getTextFieldCompra(), "cell 1 5,growx");
			panel_FormalizarCompraCentral.add(getLblTotalPuntos(), "cell 0 6,alignx left");
			panel_FormalizarCompraCentral.add(getTextFieldTotalPuntos(), "cell 1 6,growx");
			panel_FormalizarCompraCentral.add(getPanel_RadiobotonesPuntos(), "cell 0 7,grow");
			panel_FormalizarCompraCentral.add(getScrollPaneCarrito(), "cell 5 7,grow");
			panel_FormalizarCompraCentral.add(getLblTotalCompra(), "cell 4 15,alignx trailing");
			panel_FormalizarCompraCentral.add(getTextFieldTotalCompra(), "cell 5 15,growx,aligny center");
			panel_FormalizarCompraCentral.add(getPanel_BotonesFormalizarCompra(),
					"cell 5 17,alignx right,aligny bottom");
		}
		return panel_FormalizarCompraCentral;
	}

	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel("Nombre:");
			lblNombre.setDisplayedMnemonic('n');
			lblNombre.setLabelFor(getTextFieldNmbre());
		}
		return lblNombre;
	}

	private JTextField getTextFieldNmbre() {
		if (textFieldNmbre == null) {
			textFieldNmbre = new JTextField();
			textFieldNmbre.setColumns(10);
		}
		return textFieldNmbre;
	}

	private JLabel getLblApellido() {
		if (lblApellido == null) {
			lblApellido = new JLabel("Apellido:");
			lblApellido.setDisplayedMnemonic('a');
			lblApellido.setLabelFor(getTextFieldApellido());
		}
		return lblApellido;
	}

	private JTextField getTextFieldApellido() {
		if (textFieldApellido == null) {
			textFieldApellido = new JTextField();
			textFieldApellido.setColumns(10);
		}
		return textFieldApellido;
	}

	private JLabel getLblNmeroDeCuenta() {
		if (lblNmeroDeCuenta == null) {
			lblNmeroDeCuenta = new JLabel("N\u00FAmero de cuenta:");
			lblNmeroDeCuenta.setDisplayedMnemonic('u');
			lblNmeroDeCuenta.setLabelFor(getTextFieldNumeroDeCuenta());
		}
		return lblNmeroDeCuenta;
	}

	private JTextField getTextFieldNumeroDeCuenta() {
		if (textFieldNumeroDeCuenta == null) {
			textFieldNumeroDeCuenta = new JTextField();
			textFieldNumeroDeCuenta.setColumns(10);
		}
		return textFieldNumeroDeCuenta;
	}

	private JLabel getLblNif() {
		if (lblNif == null) {
			lblNif = new JLabel("Nif:");
			lblNif.setDisplayedMnemonic('i');
			lblNif.setLabelFor(getTextFieldNif());
		}
		return lblNif;
	}

	private JTextField getTextFieldNif() {
		if (textFieldNif == null) {
			textFieldNif = new JTextField();
			textFieldNif.setColumns(10);
		}
		return textFieldNif;
	}

	private JLabel getLblTotalCompra() {
		if (lblTotalCompra == null) {
			lblTotalCompra = new JLabel("Total compra:");
		}
		return lblTotalCompra;
	}

	private JTextField getTextFieldTotalCompra() {
		if (textFieldTotalCompra == null) {
			textFieldTotalCompra = new JTextField();
			textFieldTotalCompra.setEditable(false);
			textFieldTotalCompra.setColumns(10);
		}
		return textFieldTotalCompra;
	}

	private JLabel getLblPuntos() {
		if (lblPuntos == null) {
			lblPuntos = new JLabel("Puntos acumulados:");
		}
		return lblPuntos;
	}

	private JTextField getTextFieldPuntos() {
		if (textFieldPuntos == null) {
			textFieldPuntos = new JTextField();
			textFieldPuntos.setEditable(false);
			textFieldPuntos.setColumns(10);
		}
		return textFieldPuntos;
	}

	private JLabel getLblPuntosCompra() {
		if (lblPuntosCompra == null) {
			lblPuntosCompra = new JLabel("Puntos compra:");
		}
		return lblPuntosCompra;
	}

	private JLabel getLblTotalPuntos() {
		if (lblTotalPuntos == null) {
			lblTotalPuntos = new JLabel("Total puntos tras compra:");
		}
		return lblTotalPuntos;
	}

	private JTextField getTextFieldCompra() {
		if (textFieldCompra == null) {
			textFieldCompra = new JTextField();
			textFieldCompra.setEditable(false);
			textFieldCompra.setColumns(10);
		}
		return textFieldCompra;
	}

	private JTextField getTextFieldTotalPuntos() {
		if (textFieldTotalPuntos == null) {
			textFieldTotalPuntos = new JTextField();
			textFieldTotalPuntos.setEditable(false);
			textFieldTotalPuntos.setColumns(10);
		}
		return textFieldTotalPuntos;
	}

	private JPanel getPanel_RadiobotonesPuntos() {
		if (panel_RadiobotonesPuntos == null) {
			panel_RadiobotonesPuntos = new JPanel();
			panel_RadiobotonesPuntos.setLayout(new GridLayout(3, 1, 0, 0));
			panel_RadiobotonesPuntos.add(getRdbtnDescontarPuntosDel());
			panel_RadiobotonesPuntos.add(getRdbtnAcumularPuntos());
			panel_RadiobotonesPuntos.add(getRdbtnCanjearPorRegalo());
		}
		return panel_RadiobotonesPuntos;
	}

	private JRadioButton getRdbtnDescontarPuntosDel() {
		if (rdbtnDescontarPuntosDel == null) {
			rdbtnDescontarPuntosDel = new JRadioButton("Descontar puntos del precio total (1\u20AC por cada punto)");
			rdbtnDescontarPuntosDel.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					double precioTotal = Tienda.getAccionesTienda().descontarCompra();
					if (precioTotal >= 0) {
						Tienda.getAccionesTienda().setPrecioTotalCompra(Math.round(precioTotal));
						rdbtnAcumularPuntos.setEnabled(false);
						rdbtnCanjearPorRegalo.setEnabled(false);
						rdbtnDescontarPuntosDel.setEnabled(false);
						textFieldTotalPuntos.setText(String.valueOf(Tienda.getAccionesTienda().getPuntosTotalCompra()));
						textFieldTotalCompra.setText(String.valueOf(precioTotal));
						Tienda.getAccionesTienda().accionesPuntos = AccionesPuntos.DESCONTAR;
					} else {
						buttonGroup.clearSelection();
						JOptionPane.showMessageDialog(null,
								"No pueden canjearse los puntos porque la coste total del carrito es inferior al del descuento");
					}
				}
			});
			buttonGroup.add(rdbtnDescontarPuntosDel);
		}
		return rdbtnDescontarPuntosDel;
	}

	private JRadioButton getRdbtnAcumularPuntos() {
		if (rdbtnAcumularPuntos == null) {
			rdbtnAcumularPuntos = new JRadioButton("Acumular puntos para futuras compras");
			rdbtnAcumularPuntos.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					Tienda.getAccionesTienda().accionesPuntos = AccionesPuntos.ACUMULAR;
					Tienda.getAccionesTienda().acumularPuntos();
					rdbtnAcumularPuntos.setEnabled(false);
					rdbtnCanjearPorRegalo.setEnabled(false);
					rdbtnDescontarPuntosDel.setEnabled(false);
				}
			});
			buttonGroup.add(rdbtnAcumularPuntos);
		}
		return rdbtnAcumularPuntos;
	}

	private JRadioButton getRdbtnCanjearPorRegalo() {
		if (rdbtnCanjearPorRegalo == null) {
			rdbtnCanjearPorRegalo = new JRadioButton("Canjear por regalo");
			rdbtnCanjearPorRegalo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					System.out.println("puntos usuario:" + Tienda.getAccionesTienda().getUsuario().getPuntos());
					System.out.println("Regalo menos puntos:" + Tienda.getAccionesTienda().getRegaloMenosPuntos());
					if (Tienda.getAccionesTienda().getUsuario().getPuntos() >= Tienda.getAccionesTienda()
							.getRegaloMenosPuntos()) {
						VentanaCatalogoRegalos v = new VentanaCatalogoRegalos();
						v.setLocationRelativeTo(null);
						v.setVisible(true);
						v.addWindowListener(new WindowAdapter() {
							@Override
							public void windowClosed(WindowEvent e) {
								clearTablaCarrito();
								addFilasTablaCarrito(Tienda.getAccionesTienda().getCarrito(), modeloTablaCarrito);
								for (Articulo articulo : Tienda.getAccionesTienda().getCarrito()) {
									if (articulo.isRegalo()) {
										rdbtnAcumularPuntos.setEnabled(false);
										rdbtnCanjearPorRegalo.setEnabled(false);
										rdbtnDescontarPuntosDel.setEnabled(false);
										Tienda.getAccionesTienda().accionesPuntos = AccionesPuntos.REGALO;
									}
								}
								textFieldPuntos
										.setText(String.valueOf(Tienda.getAccionesTienda().getUsuario().getPuntos()));
								textFieldTotalPuntos
										.setText(String.valueOf(Tienda.getAccionesTienda().getPuntosTotalCompra()));
							}

						});
					} else {
						JOptionPane.showMessageDialog(null, "No tienes suficientes puntos para tener un regalo");
					}
				}
			});
			buttonGroup.add(rdbtnCanjearPorRegalo);
		}
		return rdbtnCanjearPorRegalo;
	}

	private void centrarColumna(String columna, JTable tabla) {
		DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
		rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
		tabla.getColumn(columna).setCellRenderer(rightRenderer);
	}

	private JScrollPane getScrollPaneCarrito() {
		if (scrollPaneCarrito == null) {
			scrollPaneCarrito = new JScrollPane();
			scrollPaneCarrito.setViewportView(getTableCarrito());
		}
		return scrollPaneCarrito;
	}

	private JTable getTableCarrito() {
		if (tableCarrito == null) {
			String[] nombreColumnas = { "Art�culo", "Precio", "Cantidad", "Puntos" };
			modeloTablaCarrito = new ModeloNoEditable(nombreColumnas, 0);
			tableCarrito = new JTable(modeloTablaCarrito);
			tableCarrito.setEnabled(false);

			for (int i = 0; i < nombreColumnas.length; i++) {
				centrarColumna(nombreColumnas[i], tableCarrito);
			}
		}
		return tableCarrito;
	}

	private JPanel getPanel_BotonesFormalizarCompra() {
		if (panel_BotonesFormalizarCompra == null) {
			panel_BotonesFormalizarCompra = new JPanel();
			panel_BotonesFormalizarCompra.add(getBtnRetrocesoFormalizarCompra());
			panel_BotonesFormalizarCompra.add(getBtnFinalizarcompra());
		}
		return panel_BotonesFormalizarCompra;
	}

	private JButton getBtnRetrocesoFormalizarCompra() {
		if (btnRetrocesoFormalizarCompra == null) {
			btnRetrocesoFormalizarCompra = new JButton("Atr\u00E1s");
			btnRetrocesoFormalizarCompra.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					((CardLayout) contentPane.getLayout()).show(contentPane, "panelInicio");
					mntmVerCarrito.setEnabled(true);
					mntmIniciarSesin.setEnabled(true);
					mntmRegistrarse.setEnabled(true);
				}
			});
		}
		return btnRetrocesoFormalizarCompra;
	}

	private JButton getBtnFinalizarcompra() {
		if (btnFinalizarcompra == null) {
			btnFinalizarcompra = new JButton("Finalizar Compra");
			btnFinalizarcompra.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					if (isCamposCubiertos()) {
						if (Tienda.getAccionesTienda().getUsuario() == null) {
							Cliente cl = new Cliente("NOVIP", textFieldNmbre.getText(), textFieldApellido.getText(),
									textFieldNif.getText(), "", "", "", textFieldNumeroDeCuenta.getText(),
									Integer.valueOf(textFieldTotalPuntos.getText()));
							Tienda.getAccionesTienda().setUsuario(cl);
							try {
								textAreaResumenFinalCompra.setText(Tienda.getAccionesTienda().mostrarEstadoCompra());
							} catch (ParseException e) {
								e.printStackTrace();
							}
							((CardLayout) contentPane.getLayout()).show(contentPane, "panelFinCompra");

						} else if (Tienda.getAccionesTienda().getUsuario() != null) {
							try {
								if (Tienda.getAccionesTienda().getUsuario() != null && !selecionadaAccionPuntos()) {
									textAreaResumenFinalCompra
											.setText(Tienda.getAccionesTienda().mostrarEstadoCompra());
									((CardLayout) contentPane.getLayout()).show(contentPane, "panelFinCompra");
								} else
									JOptionPane.showMessageDialog(null,
											"Seleccione una accion a realizar con los puntos");
							} catch (ParseException e) {
								e.printStackTrace();
							}
						}

					} else
						JOptionPane.showMessageDialog(null, "Complete todos los campos del formulario");

				}
			});
		}
		return btnFinalizarcompra;
	}

	private boolean selecionadaAccionPuntos() {
		if (!rdbtnAcumularPuntos.isSelected() || !rdbtnCanjearPorRegalo.isSelected()
				|| !rdbtnDescontarPuntosDel.isSelected())
			return false;
		return true;
	}

	// ----------------------------------------------------------//
	// Ventana final compra
	// ----------------------------------------------------------//

	private JPanel getPanelFinCompra() {
		if (panelFinCompra == null) {
			panelFinCompra = new JPanel();
			panelFinCompra.setLayout(new BorderLayout(0, 0));
			panelFinCompra.add(getTextAreaResumenFinalCompra());
			panelFinCompra.add(getPanel_BotonesFinCompra(), BorderLayout.SOUTH);
		}
		return panelFinCompra;
	}

	private JTextArea getTextAreaResumenFinalCompra() {
		if (textAreaResumenFinalCompra == null) {
			textAreaResumenFinalCompra = new JTextArea();
			textAreaResumenFinalCompra.setEditable(false);
			textAreaResumenFinalCompra.setWrapStyleWord(true);
			textAreaResumenFinalCompra.setLineWrap(true);
		}
		return textAreaResumenFinalCompra;
	}

	private JPanel getPanel_BotonesFinCompra() {
		if (panel_BotonesFinCompra == null) {
			panel_BotonesFinCompra = new JPanel();
			panel_BotonesFinCompra.setLayout(new FlowLayout(FlowLayout.CENTER, 5, 5));
			panel_BotonesFinCompra.add(getBtnAtrs());
			panel_BotonesFinCompra.add(getBtnConfirmarCompra());
		}
		return panel_BotonesFinCompra;
	}

	private JButton getBtnAtrs() {
		if (btnAtrs == null) {
			btnAtrs = new JButton("Atr\u00E1s");
			btnAtrs.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					((CardLayout) contentPane.getLayout()).show(contentPane, "panelFormalizarCompra");
				}
			});
		}
		return btnAtrs;
	}

	private JButton getBtnConfirmarCompra() {
		if (btnConfirmarCompra == null) {
			btnConfirmarCompra = new JButton("Confirmar compra");
			btnConfirmarCompra.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					try {
						Tienda.getAccionesTienda().imprimirFactura();
						Tienda.getAccionesTienda().actualizarUsuarios();
						Tienda.getAccionesTienda().cerrarSesion();
						((CardLayout) contentPane.getLayout()).show(contentPane, "panelInicio");
						btnAddElementoCarrito.setEnabled(false);
						btnTramitarCompra.setEnabled(false);
						actualizarInformacionUsuario();
						mntmIniciarSesin.setEnabled(true);
						mntmRegistrarse.setEnabled(true);
						reiniciarFormularioDatos();
					} catch (ParseException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}

			});
		}
		return btnConfirmarCompra;
	}

	private void reiniciarFormularioDatos() {
		textFieldNmbre.setText("");
		textFieldNmbre.setEditable(true);
		textFieldApellido.setText("");
		textFieldApellido.setEditable(true);
		textFieldNif.setText("");
		textFieldNif.setEditable(true);
		textFieldNumeroDeCuenta.setEditable(true);
		textFieldNumeroDeCuenta.setText("");

	}

	private boolean isCamposCubiertos() {
		if (textFieldApellido.getText().equals("") || textFieldNif.getText().equals("")
				|| textFieldNmbre.getText().equals("") || textFieldNumeroDeCuenta.getText().equals(""))
			return false;
		return true;
	}

	private void cargaAyuda() {
		URL hsURL;
		HelpSet hs;
		try {
			File fichero = new File("help/Ayuda.hs");
			hsURL = fichero.toURI().toURL();
			hs = new HelpSet(null, hsURL);
		} catch (Exception e) {
			System.out.println("Ayuda no encontrada");
			return;
		}
		HelpBroker hb = hs.createHelpBroker();
		hb.initPresentation();

		hb.enableHelpKey(getRootPane(), "inicio", hs);
		hb.enableHelpOnButton(getMntmAyudaDeEii(), "inicio", hs);
	}

	private JMenu getMnAyuda() {
		if (mnAyuda == null) {
			mnAyuda = new JMenu("Ayuda");
			mnAyuda.setMnemonic('Y');
			mnAyuda.add(getMntmAyudaDeEii());
			mnAyuda.add(getSeparator_ayuda());
			mnAyuda.add(getMntmAcercaDeEii());
		}
		return mnAyuda;
	}

	private JMenuItem getMntmAyudaDeEii() {
		if (mntmAyudaDeEii == null) {
			mntmAyudaDeEii = new JMenuItem("Ayuda de EII market");
			mntmAyudaDeEii.setMnemonic('a');
		}
		return mntmAyudaDeEii;
	}

	private JMenuItem getMntmAcercaDeEii() {
		if (mntmAcercaDeEii == null) {
			mntmAcercaDeEii = new JMenuItem("Acerca de EII market");
			mntmAcercaDeEii.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					JOptionPane.showMessageDialog(null, "EII market\nBenigno Diez Guti�rrez-71734673L-UO227982");
				}
			});
			mntmAcercaDeEii.setMnemonic('c');
		}
		return mntmAcercaDeEii;
	}

	private JLabel getLblPrecioMnimo() {
		if (lblPrecioMnimo == null) {
			lblPrecioMnimo = new JLabel("Precio m\u00EDnimo: ");
			lblPrecioMnimo.setLabelFor(getTextFieldPrecioMinimo());
			lblPrecioMnimo.setDisplayedMnemonic('i');
		}
		return lblPrecioMnimo;
	}

	private JLabel getLblPrecioMximo() {
		if (lblPrecioMximo == null) {
			lblPrecioMximo = new JLabel("Precio m\u00E1ximo:");
			lblPrecioMximo.setDisplayedMnemonic('a');
			lblPrecioMximo.setLabelFor(getTextFieldPrecioMaximo());
		}
		return lblPrecioMximo;
	}

	private JSeparator getSeparator_ayuda() {
		if (separator_ayuda == null) {
			separator_ayuda = new JSeparator();
		}
		return separator_ayuda;
	}

	private JMenuItem getMntmCerrarSesin() {
		if (mntmCerrarSesin == null) {
			mntmCerrarSesin = new JMenuItem("Cerrar sesi\u00F3n");
			mntmCerrarSesin.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					Tienda.getAccionesTienda().cerrarSesion();
					btnTramitarCompra.setEnabled(false);
					actualizarInformacionUsuario();
					mntmVerCarrito.setEnabled(false);
					tableItemsVenta.setEnabled(true);
				}
			});
		}
		return mntmCerrarSesin;
	}

	private JLabel getLblVIP() {
		if (lblVIP == null) {
			lblVIP = new JLabel("");
		}
		return lblVIP;
	}

	private JSeparator getSeparator_1() {
		if (separator_1 == null) {
			separator_1 = new JSeparator();
		}
		return separator_1;
	}
}
