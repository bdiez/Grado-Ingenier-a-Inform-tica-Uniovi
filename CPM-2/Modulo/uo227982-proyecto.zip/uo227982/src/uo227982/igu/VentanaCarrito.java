package uo227982.igu;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;

import uo227982.igu.util.ModeloNoEditable;
import uo227982.logica.acciones.Tienda;
import uo227982.logica.modelo.Articulo;

public class VentanaCarrito extends JDialog {

	private static final long serialVersionUID = 1L;
	private JScrollPane scrollPaneCarrito;
	private JTable tableElementosCarrito;
	private ModeloNoEditable modeloTabla;
	private JPanel PanelSur;
	private JButton btnBorrarDelCarrito;

	public VentanaCarrito() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(VentanaCarrito.class.getResource("/uo227982/img/logo.PNG")));
		setTitle("Eii market - Carrito");
		setBounds(100, 100, 574, 353);
		getContentPane().add(getScrollPaneCarrito(), BorderLayout.CENTER);
		getContentPane().add(getPanelSur(), BorderLayout.SOUTH);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

	}

	private JScrollPane getScrollPaneCarrito() {
		if (scrollPaneCarrito == null) {
			scrollPaneCarrito = new JScrollPane();
			scrollPaneCarrito.setViewportView(getTableElementosCarrito());
		}
		return scrollPaneCarrito;
	}

	private JTable getTableElementosCarrito() {
		if (tableElementosCarrito == null) {
			String[] nombreColumnas = { "Art�culo", "Precio", "Cantidad", "Puntos" };
			modeloTabla = new ModeloNoEditable(nombreColumnas, 0);
			tableElementosCarrito = new JTable(modeloTabla);
			tableElementosCarrito.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			a�adirFilas(Tienda.getAccionesTienda().getCarrito());
			tableElementosCarrito.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					btnBorrarDelCarrito.setEnabled(true);
				}
			});
			for (int i = 0; i < nombreColumnas.length; i++) {
				centrarColumna(nombreColumnas[i]);
			}

		}
		return tableElementosCarrito;
	}

	private JPanel getPanelSur() {
		if (PanelSur == null) {
			PanelSur = new JPanel();
			PanelSur.add(getBtnBorrarDelCarrito());
		}
		return PanelSur;
	}

	private JButton getBtnBorrarDelCarrito() {
		if (btnBorrarDelCarrito == null) {
			btnBorrarDelCarrito = new JButton("Borrar del carrito");
			btnBorrarDelCarrito.setMnemonic('B');
			btnBorrarDelCarrito.setEnabled(false);
			btnBorrarDelCarrito.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					int row = tableElementosCarrito.getSelectedRow();
					Articulo articulo = Tienda.getAccionesTienda().getCarrito().get(row);
					Tienda.getAccionesTienda().removeElementoCarrito(articulo);
					clearTabla();
					a�adirFilas(Tienda.getAccionesTienda().getCarrito());
					if (tableElementosCarrito.getRowCount() == 0)
						btnBorrarDelCarrito.setEnabled(false);
				}
			});
		}
		return btnBorrarDelCarrito;
	}

	/**
	 * Metodo que vacia de elementos una tabla
	 */
	private void clearTabla() {
		for (int i = 0; i < tableElementosCarrito.getRowCount(); i++) {
			modeloTabla.removeRow(i);
			i -= 1;
		}
	}

	/**
	 * MEtodo que centra los elementos de la columna
	 * 
	 * @param columna
	 */
	private void centrarColumna(String columna) {
		DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
		rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
		tableElementosCarrito.getColumn(columna).setCellRenderer(rightRenderer);
	}

	/**
	 * A�ade las filas a la tabla
	 * 
	 * @param articulos
	 */
	private void a�adirFilas(List<Articulo> articulos) {
		Object[] nuevaFila = new Object[6];
		for (Articulo articulo : articulos) {
			nuevaFila[0] = articulo.getDenominacion();
			nuevaFila[1] = articulo.getPrecio();
			nuevaFila[2] = articulo.getStock();
			nuevaFila[3] = articulo.getPuntosAsociados();

			modeloTabla.addRow(nuevaFila);
		}
	}
}
