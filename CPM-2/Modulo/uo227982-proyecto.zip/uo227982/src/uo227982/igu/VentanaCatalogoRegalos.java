package uo227982.igu;

import java.awt.BorderLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;

import uo227982.igu.util.ModeloNoEditable;
import uo227982.logica.acciones.Tienda;
import uo227982.logica.modelo.Articulo;

public class VentanaCatalogoRegalos extends JDialog {
	private static final long serialVersionUID = 1L;
	private JTable tableCatalogoRegalos;
	private ModeloNoEditable modeloTabla;
	private JScrollPane scrollPane;
	private JPanel panelBotones;
	private JButton btnSeleccionarRegalo;

	/**
	 * Create the dialog.
	 */
	public VentanaCatalogoRegalos() {
		setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
		setModal(true);
		setResizable(false);
		setTitle("Eii market - Cat\u00E1logo regalos");
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(VentanaCatalogoRegalos.class.getResource("/uo227982/img/logo.PNG")));
		setBounds(100, 100, 438, 359);
		getContentPane().add(getPanelBotones(), BorderLayout.SOUTH);
		getContentPane().add(getScrollPane(), BorderLayout.CENTER);

	}

	private JTable getTableCatalogoRegalos() {
		if (tableCatalogoRegalos == null) {
			tableCatalogoRegalos = new JTable();
			String[] nombreColumnas = { "Art�culo", "Categoria", "Valor" };
			modeloTabla = new ModeloNoEditable(nombreColumnas, 0);
			tableCatalogoRegalos = new JTable(modeloTabla);
			tableCatalogoRegalos.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
			a�adirFilas(Tienda.getAccionesTienda().getRegalosByPuntosUsuario());
			tableCatalogoRegalos.addMouseListener(new MouseAdapter() {
				@Override
				public void mouseClicked(MouseEvent e) {
					btnSeleccionarRegalo.setEnabled(true);
				}
			});
			for (int i = 0; i < nombreColumnas.length; i++) {
				centrarColumna(nombreColumnas[i]);
			}

		}
		return tableCatalogoRegalos;
	}

	/**
	 * Metodo que centra los elementos de la columna
	 * 
	 * @param columna
	 */
	private void centrarColumna(String columna) {
		DefaultTableCellRenderer rightRenderer = new DefaultTableCellRenderer();
		rightRenderer.setHorizontalAlignment(DefaultTableCellRenderer.CENTER);
		tableCatalogoRegalos.getColumn(columna).setCellRenderer(rightRenderer);
	}

	/**
	 * A�ade las filas a la tabla
	 * 
	 * @param articulos
	 */
	private void a�adirFilas(List<Articulo> articulos) {
		Object[] nuevaFila = new Object[3];
		for (Articulo articulo : articulos) {
			nuevaFila[0] = articulo.getDenominacion();
			nuevaFila[1] = articulo.getCategoria();
			nuevaFila[2] = articulo.getPuntosAsociados();
			modeloTabla.addRow(nuevaFila);
		}
	}

	private JScrollPane getScrollPane() {
		if (scrollPane == null) {
			scrollPane = new JScrollPane();
			scrollPane.setViewportView(getTableCatalogoRegalos());
		}
		return scrollPane;
	}

	private JPanel getPanelBotones() {
		if (panelBotones == null) {
			panelBotones = new JPanel();
			panelBotones.add(getBtnSeleccionarRegalo());
		}
		return panelBotones;
	}

	private JButton getBtnSeleccionarRegalo() {
		if (btnSeleccionarRegalo == null) {
			btnSeleccionarRegalo = new JButton("Seleccionar regalo");
			btnSeleccionarRegalo.setEnabled(false);
			btnSeleccionarRegalo.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent arg0) {
					String nombreArticulo = (String) modeloTabla.getValueAt(tableCatalogoRegalos.getSelectedRow(), 0);
					Articulo articulo = Tienda.getAccionesTienda().getAccionesArticulo()
							.findByDenominacion(Tienda.getAccionesTienda().getRegalos(), nombreArticulo);
					articulo.setPuntosAsociados(-articulo.getPuntosAsociados());
					articulo.setRegalo(true);
					Tienda.getAccionesTienda().addArticuloCarrito(articulo, 1);
					Tienda.getAccionesTienda().descontarPuntosRegalo();
					dispose();
				}
			});
		}
		return btnSeleccionarRegalo;
	}
}
