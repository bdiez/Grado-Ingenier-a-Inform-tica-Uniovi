package uo227982.igu;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.NumberFormat;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFormattedTextField;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import javax.swing.text.NumberFormatter;

import uo227982.logica.acciones.AccionesCliente;
import uo227982.logica.acciones.Tienda;
import uo227982.logica.modelo.Cliente;

public class VentanaRegistroUsuario extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel lblNombre;
	private JLabel lblApellido;
	private JLabel lblNIF;
	private JTextField textFieldNombre;
	private JTextField textFieldApellido;
	private JFormattedTextField textFieldNif;
	private JLabel lblNombreDeUsuario;
	private JTextField textFieldNombreDeUsuario;
	private JLabel lblContrasea;
	private JLabel lblRepetirContrasea;
	private JPasswordField passwordField1;
	private JPasswordField passwordFieldRepetida;
	private JLabel lblTelfono;
	private JLabel lblNmeroDeTarjeta;
	private JFormattedTextField textFieldNumeroDeTarjeta;
	private JFormattedTextField textFieldDeTelefono;
	private JPanel panelDatosUsuario;
	private JPanel panelDatosCuenta;
	private JPanel panelDatosBancarios;

	public VentanaRegistroUsuario() {
		setIconImage(Toolkit.getDefaultToolkit()
				.getImage(VentanaRegistroUsuario.class.getResource("/uo227982/img/logo.PNG")));
		setModal(true);
		setResizable(false);
		setTitle("Eii Market - Registro usuarios");
		setBounds(100, 100, 644, 343);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		contentPanel.add(getPanelDatosUsuario());
		contentPanel.add(getPanelDatosCuenta());
		contentPanel.add(getPanelDatosBancarios());
		JPanel buttonPane = panelPrincipal();
		botonAceptar(buttonPane);
		botonCancelar(buttonPane);

	}

	private void botonCancelar(JPanel buttonPane) {
		JButton cancelButton = new JButton("Cancelar");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}

		});
		buttonPane.add(cancelButton);
	}

	private Cliente getDatosUsuario() {
		if (camposCubiertos() && comprobarPass()) {
			if (!isExisteUsuario()) {
				if (nifCorrecto()) {
					Cliente cliente = new Cliente("NOVIP", getTextFieldNombre().getText(), getTextFieldApellido().getText(),
							getTextFieldNif().getText(), getTextFieldNombreDeUsuario().getText(),
							String.valueOf(getPasswordFieldRepetida().getPassword()),
							getTextFieldDeTelefono().getText(), getTextFieldNumeroDeTarjeta().getText(), 0);
					return cliente;
				} else {
					return null;
				}
			} else {
				JOptionPane.showMessageDialog(null, "Ya existe un usuario con ese nombre de usuario");
				return null;
			}
		} else {
			JOptionPane.showMessageDialog(null, "Hay campos que no estan cubiertos");
			return null;
		}

	}

	private boolean nifCorrecto() {
		String nif = String.valueOf(textFieldNif.getText());
		for (int i = 0; i < nif.length() - 1; ++i) {
			char caracter = nif.charAt(i);
			if (!Character.isDigit(caracter)) {
				JOptionPane.showMessageDialog(null, "El formato del NIF no es correcto");
				return false;
			}
		}
		if (!Character.isAlphabetic(nif.charAt(nif.length() - 1))) {
			JOptionPane.showMessageDialog(null, "El �ltimo caracter del nif debe de ser una letra");
			return false;
		}
		return true;
	}

	private boolean isExisteUsuario() {
		List<Cliente> clientes = Tienda.getAccionesTienda().getClientes();
		for (Cliente cliente : clientes) {
			if (cliente.getNombreUsuario().equals(textFieldNombreDeUsuario.getText()))
				return true;
		}
		return false;
	}

	private void botonAceptar(JPanel buttonPane) {
		JButton okButton = new JButton("Registrarse");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				AccionesCliente ac = new AccionesCliente();
				Cliente usuario = getDatosUsuario();
				if (usuario != null)
					try {
						ac.addUsuario(usuario);
						dispose();
						JOptionPane.showMessageDialog(null, "Ha sido registrado correctamente");
					} catch (Exception e) {
						JOptionPane.showMessageDialog(null, "Ya existe otro usuario con ese nif");
					}
			}
		});
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
	}

	private JPanel panelPrincipal() {
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
		return buttonPane;
	}

	private JLabel getLblNombre() {
		if (lblNombre == null) {
			lblNombre = new JLabel("Nombre:");
			lblNombre.setDisplayedMnemonic('N');
			lblNombre.setLabelFor(getTextFieldNombre());
			lblNombre.setBounds(10, 28, 76, 14);
		}
		return lblNombre;
	}

	private JLabel getLblApellido() {
		if (lblApellido == null) {
			lblApellido = new JLabel("Apellido:");
			lblApellido.setDisplayedMnemonic('A');
			lblApellido.setLabelFor(getTextFieldApellido());
			lblApellido.setBounds(10, 56, 76, 14);
		}
		return lblApellido;
	}

	private JLabel getLblNIF() {
		if (lblNIF == null) {
			lblNIF = new JLabel("Nif:");
			lblNIF.setDisplayedMnemonic('i');
			lblNIF.setLabelFor(getTextFieldNif());
			lblNIF.setBounds(10, 109, 46, 14);
		}
		return lblNIF;
	}

	private JTextField getTextFieldNombre() {
		if (textFieldNombre == null) {
			textFieldNombre = new JTextField();
			textFieldNombre.setBounds(96, 25, 191, 20);
			textFieldNombre.setColumns(10);
		}
		return textFieldNombre;
	}

	private JTextField getTextFieldApellido() {
		if (textFieldApellido == null) {
			textFieldApellido = new JTextField();
			textFieldApellido.setText("");
			textFieldApellido.setBounds(96, 53, 191, 20);
			textFieldApellido.setColumns(10);
		}
		return textFieldApellido;
	}

	private JFormattedTextField getTextFieldNif() {
		if (textFieldNif == null) {
			textFieldNif = new JFormattedTextField();
			textFieldNif.setBounds(96, 106, 191, 20);
			textFieldNif.setColumns(10);
		}
		return textFieldNif;
	}

	private JLabel getLblNombreDeUsuario() {
		if (lblNombreDeUsuario == null) {
			lblNombreDeUsuario = new JLabel("Nombre de usuario:");
			lblNombreDeUsuario.setDisplayedMnemonic('o');
			lblNombreDeUsuario.setLabelFor(getTextFieldNombreDeUsuario());
			lblNombreDeUsuario.setBounds(13, 32, 124, 14);
		}
		return lblNombreDeUsuario;
	}

	private JTextField getTextFieldNombreDeUsuario() {
		if (textFieldNombreDeUsuario == null) {
			textFieldNombreDeUsuario = new JTextField();
			textFieldNombreDeUsuario.setBounds(147, 29, 120, 20);
			textFieldNombreDeUsuario.setColumns(10);
		}
		return textFieldNombreDeUsuario;
	}

	private JLabel getLblContrasea() {
		if (lblContrasea == null) {
			lblContrasea = new JLabel("Contrase\u00F1a:");
			lblContrasea.setDisplayedMnemonic('C');
			lblContrasea.setLabelFor(getPasswordField1());
			lblContrasea.setBounds(13, 63, 93, 14);
		}
		return lblContrasea;
	}

	private JLabel getLblRepetirContrasea() {
		if (lblRepetirContrasea == null) {
			lblRepetirContrasea = new JLabel("Repetir contrase\u00F1a:");
			lblRepetirContrasea.setDisplayedMnemonic('r');
			lblRepetirContrasea.setLabelFor(getPasswordFieldRepetida());
			lblRepetirContrasea.setBounds(10, 96, 127, 14);
		}
		return lblRepetirContrasea;
	}

	private JPasswordField getPasswordField1() {
		if (passwordField1 == null) {
			passwordField1 = new JPasswordField();
			passwordField1.setBounds(147, 60, 120, 20);
		}
		return passwordField1;
	}

	private JPasswordField getPasswordFieldRepetida() {
		if (passwordFieldRepetida == null) {
			passwordFieldRepetida = new JPasswordField();
			passwordFieldRepetida.setBounds(147, 93, 120, 20);
		}
		return passwordFieldRepetida;
	}

	private JLabel getLblTelfono() {
		if (lblTelfono == null) {
			lblTelfono = new JLabel("Tel\u00E9fono:");
			lblTelfono.setDisplayedMnemonic('T');
			lblTelfono.setLabelFor(getTextFieldDeTelefono());
			lblTelfono.setBounds(10, 81, 99, 14);
		}
		return lblTelfono;
	}

	private JLabel getLblNmeroDeTarjeta() {
		if (lblNmeroDeTarjeta == null) {
			lblNmeroDeTarjeta = new JLabel("N\u00FAmero de tarjeta: ");
			lblNmeroDeTarjeta.setDisplayedMnemonic('m');
			lblNmeroDeTarjeta.setLabelFor(getTextFieldNumeroDeTarjeta());
			lblNmeroDeTarjeta.setBounds(10, 31, 116, 14);
		}
		return lblNmeroDeTarjeta;
	}

	private JTextField getTextFieldNumeroDeTarjeta() {
		if (textFieldNumeroDeTarjeta == null) {
			textFieldNumeroDeTarjeta = new JFormattedTextField(formatoNumero());
			textFieldNumeroDeTarjeta.setBounds(120, 28, 161, 20);
			textFieldNumeroDeTarjeta.setColumns(10);
		}
		return textFieldNumeroDeTarjeta;
	}

	private JTextField getTextFieldDeTelefono() {
		if (textFieldDeTelefono == null) {
			textFieldDeTelefono = new JFormattedTextField(formatoNumeroTelefono());
			textFieldDeTelefono.setBounds(96, 78, 191, 20);
			textFieldDeTelefono.setColumns(10);
		}
		return textFieldDeTelefono;
	}

	private JPanel getPanelDatosUsuario() {
		if (panelDatosUsuario == null) {
			panelDatosUsuario = new JPanel();
			panelDatosUsuario.setBorder(
					new TitledBorder(null, "Datos usuario", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelDatosUsuario.setBounds(10, 11, 306, 152);
			panelDatosUsuario.setLayout(null);
			panelDatosUsuario.add(getTextFieldApellido());
			panelDatosUsuario.add(getLblApellido());
			panelDatosUsuario.add(getLblNombre());
			panelDatosUsuario.add(getTextFieldNombre());
			panelDatosUsuario.add(getTextFieldNif());
			panelDatosUsuario.add(getLblNIF());
			panelDatosUsuario.add(getTextFieldDeTelefono());
			panelDatosUsuario.add(getLblTelfono());
		}
		return panelDatosUsuario;
	}

	private JPanel getPanelDatosCuenta() {
		if (panelDatosCuenta == null) {
			panelDatosCuenta = new JPanel();
			panelDatosCuenta.setBorder(
					new TitledBorder(null, "Datos Cuenta", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelDatosCuenta.setLayout(null);
			panelDatosCuenta.add(getPasswordField1());
			panelDatosCuenta.add(getPasswordFieldRepetida());
			panelDatosCuenta.add(getTextFieldNombreDeUsuario());
			panelDatosCuenta.add(getLblNombreDeUsuario());
			panelDatosCuenta.add(getLblContrasea());
			panelDatosCuenta.add(getLblRepetirContrasea());
			panelDatosCuenta.setBounds(326, 11, 292, 152);
		}
		return panelDatosCuenta;
	}

	private JPanel getPanelDatosBancarios() {
		if (panelDatosBancarios == null) {
			panelDatosBancarios = new JPanel();
			panelDatosBancarios.setBorder(
					new TitledBorder(null, "Datos bancarios", TitledBorder.LEADING, TitledBorder.TOP, null, null));
			panelDatosBancarios.setBounds(10, 184, 306, 76);
			panelDatosBancarios.setLayout(null);
			panelDatosBancarios.add(getLblNmeroDeTarjeta());
			panelDatosBancarios.add(getTextFieldNumeroDeTarjeta());
		}
		return panelDatosBancarios;
	}

	/**
	 * Metodo que da un formato a los n�meros de un jtextfield
	 * 
	 * @return formato del jtextfield
	 */

	private NumberFormatter formatoNumeroTelefono() {
		NumberFormat format = NumberFormat.getInstance();
		NumberFormatter formatter = new NumberFormatter(format);
		formatter.setValueClass(Integer.class);
		formatter.setMinimum(0);
		formatter.setMaximum(999999999);
		formatter.setAllowsInvalid(false);
		formatter.setCommitsOnValidEdit(true);
		return formatter;
	}

	private NumberFormatter formatoNumero() {
		NumberFormat format = NumberFormat.getInstance();
		NumberFormatter formatter = new NumberFormatter(format);
		formatter.setValueClass(Integer.class);
		formatter.setMinimum(0);
		formatter.setMaximum(Integer.MAX_VALUE);
		formatter.setAllowsInvalid(false);
		formatter.setCommitsOnValidEdit(true);
		return formatter;
	}

	/*
	 * Metodo que comprueba que las contrase�as de los campos de texto coinciden
	 */
	private boolean comprobarPass() {
		String pass1 = String.valueOf(getPasswordField1().getPassword());
		String pass2 = String.valueOf(getPasswordFieldRepetida().getPassword());
		if (pass1.equals(pass2)) {
			if (pass1.length() >= 8) {
				if (isCaracterCorrecto(pass1))
					return true;
				else {
					JOptionPane.showMessageDialog(null, "La contrase�a debe de contener numeros y digitos");
					return false;
				}
			} else {
				JOptionPane.showMessageDialog(null, "La contrase�a debe de tener minimo 8 caracteres");
				return false;
			}

		} else {
			JOptionPane.showMessageDialog(null, "Las contrase�as no coinciden");
			return false;
		}
	}

	private boolean isCaracterCorrecto(String cad) {
		for (int i = 0; i < cad.length(); ++i) {
			char caracter = cad.charAt(i);
			if (!Character.isLetterOrDigit(caracter)) {
				return false;
			}
		}
		return true;
	}

	/**
	 * Metodo que comprueba si todos los campos del formulario estan cubiertos
	 * 
	 * @return
	 */
	private boolean camposCubiertos() {
		if (!getTextFieldNombre().getText().equals("") && !getTextFieldApellido().getText().equals("")
				&& !getTextFieldNif().getText().equals("") && !getTextFieldNombreDeUsuario().getText().equals("")
				&& getPasswordField1().getPassword().length != 0 && getPasswordFieldRepetida().getPassword().length != 0
				&& !getTextFieldDeTelefono().getText().equals("")
				&& !getTextFieldNumeroDeTarjeta().getText().equals(""))
			return true;
		return false;
	}

}
