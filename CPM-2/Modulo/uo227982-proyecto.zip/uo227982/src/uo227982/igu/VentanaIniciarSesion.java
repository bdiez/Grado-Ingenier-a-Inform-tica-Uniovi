package uo227982.igu;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;

import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import uo227982.logica.acciones.AccionesCliente;
import uo227982.logica.acciones.Tienda;
import uo227982.logica.modelo.Cliente;
import java.awt.Toolkit;

public class VentanaIniciarSesion extends JDialog {

	private static final long serialVersionUID = 1L;
	private final JPanel contentPanel = new JPanel();
	private JLabel lblNombreDeUsuario;
	private JTextField textFieldNombreUsuario;
	private JLabel lblContrasea;
	private JPasswordField passwordField;
	private Cliente clienteSesion;

	public VentanaIniciarSesion() {
		setTitle("Eii market - Iniciar sesion");
		setIconImage(
				Toolkit.getDefaultToolkit().getImage(VentanaIniciarSesion.class.getResource("/uo227982/img/logo.PNG")));
		setModal(true);
		setResizable(false);
		setBounds(100, 100, 272, 286);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		JPanel buttonPane = new JPanel();
		buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
		botonOK(buttonPane);
		botonCancel(buttonPane);
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		GridBagLayout gbl_contentPanel = new GridBagLayout();
		gbl_contentPanel.columnWidths = new int[] { 250, 0 };
		gbl_contentPanel.rowHeights = new int[] { 54, 31, 43, 28, 0 };
		gbl_contentPanel.columnWeights = new double[] { 0.0, Double.MIN_VALUE };
		gbl_contentPanel.rowWeights = new double[] { 0.0, 0.0, 0.0, 0.0, Double.MIN_VALUE };
		contentPanel.setLayout(gbl_contentPanel);
		GridBagConstraints gbc_lblNombreDeUsuario = new GridBagConstraints();
		gbc_lblNombreDeUsuario.fill = GridBagConstraints.BOTH;
		gbc_lblNombreDeUsuario.insets = new Insets(0, 0, 5, 0);
		gbc_lblNombreDeUsuario.gridx = 0;
		gbc_lblNombreDeUsuario.gridy = 0;
		contentPanel.add(getLblNombreDeUsuario(), gbc_lblNombreDeUsuario);
		GridBagConstraints gbc_textFieldNombreUsuario = new GridBagConstraints();
		gbc_textFieldNombreUsuario.fill = GridBagConstraints.BOTH;
		gbc_textFieldNombreUsuario.insets = new Insets(0, 0, 5, 0);
		gbc_textFieldNombreUsuario.gridx = 0;
		gbc_textFieldNombreUsuario.gridy = 1;
		contentPanel.add(getTextFieldNombreUsuario(), gbc_textFieldNombreUsuario);
		GridBagConstraints gbc_lblContrasea = new GridBagConstraints();
		gbc_lblContrasea.fill = GridBagConstraints.BOTH;
		gbc_lblContrasea.insets = new Insets(0, 0, 5, 0);
		gbc_lblContrasea.gridx = 0;
		gbc_lblContrasea.gridy = 2;
		contentPanel.add(getLblContrasea(), gbc_lblContrasea);
		GridBagConstraints gbc_passwordField = new GridBagConstraints();
		gbc_passwordField.fill = GridBagConstraints.BOTH;
		gbc_passwordField.gridx = 0;
		gbc_passwordField.gridy = 3;
		contentPanel.add(getPasswordField(), gbc_passwordField);
		getContentPane().add(buttonPane, BorderLayout.SOUTH);
	}

	private void botonCancel(JPanel buttonPane) {
		JButton cancelButton = new JButton("Cancelar");
		cancelButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent arg0) {
				dispose();
			}
		});
		cancelButton.setActionCommand("Cancel");
		buttonPane.add(cancelButton);
	}

	private void botonOK(JPanel buttonPane) {
		JButton okButton = new JButton("Iniciar sesi\u00F3n");
		okButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if (comprobarUsuarioPass()) {
					Tienda.getAccionesTienda().iniciarSesionUsuario(clienteSesion);
					dispose();
				} else
					JOptionPane.showMessageDialog(null, "El usuario y la contrase�a no son correctos");
			}

		});
		okButton.setActionCommand("OK");
		buttonPane.add(okButton);
		getRootPane().setDefaultButton(okButton);
	}

	private JLabel getLblNombreDeUsuario() {
		if (lblNombreDeUsuario == null) {
			lblNombreDeUsuario = new JLabel("Nombre de usuario");
			lblNombreDeUsuario.setDisplayedMnemonic('N');
			lblNombreDeUsuario.setLabelFor(getTextFieldNombreUsuario());
		}
		return lblNombreDeUsuario;
	}

	private JTextField getTextFieldNombreUsuario() {
		if (textFieldNombreUsuario == null) {
			textFieldNombreUsuario = new JTextField();
			textFieldNombreUsuario.setColumns(10);
		}
		return textFieldNombreUsuario;
	}

	private JLabel getLblContrasea() {
		if (lblContrasea == null) {
			lblContrasea = new JLabel("Contrase\u00F1a");
			lblContrasea.setDisplayedMnemonic('C');
			lblContrasea.setLabelFor(getPasswordField());
		}
		return lblContrasea;
	}

	private JPasswordField getPasswordField() {
		if (passwordField == null) {
			passwordField = new JPasswordField();
		}
		return passwordField;
	}

	/**
	 * Metodo que comprueba si los datos introducidos por el usuario son
	 * correctos
	 * 
	 * @return
	 */
	private boolean comprobarUsuarioPass() {
		AccionesCliente ac = new AccionesCliente();
		List<Cliente> clientes = ac.getUsuarios();
		for (Cliente cliente : clientes) {
			if (cliente.getNombreUsuario().equals(getTextFieldNombreUsuario().getText())
					&& cliente.getContrase�a().equals(String.valueOf(passwordField.getPassword()))) {
				this.clienteSesion = cliente;
				return true;
			}
		}
		return false;

	}
}
